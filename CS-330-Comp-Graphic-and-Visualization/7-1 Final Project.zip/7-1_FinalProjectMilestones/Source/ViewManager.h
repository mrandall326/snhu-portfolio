///////////////////////////////////////////////////////////////////////////////
// ViewManager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MODIFIED BY: Matthew Randall
//  Course: CS 330 - Computational Graphics and Visualization
//  Date: July 22, 2026
//  Milestone Three: Added the Mouse_Scroll_Callback declaration to
//  support adjusting the camera movement speed with the mouse wheel.
//
//  Date: August 12, 2026
//  Added the GetCameraSpeedFraction() declaration, which reports
//  that same speed as a fraction of its range for the on-screen
//  speed indicator drawn by SceneManager. It is public and static
//  because SceneManager calls it from outside this class, without
//  an instance.
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h" 

class ViewManager
{
public:
	// constructor
	ViewManager(
		ShaderManager* pShaderManager);
	// destructor
	~ViewManager();

	// mouse position callback for mouse interaction with the 3D scene
	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

	// mouse scroll wheel callback for adjusting the speed at which
	// the camera moves through the 3D scene
	// (added by Matthew Randall for Milestone Three)
	static void Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

	// reports the camera's current movement speed as a 0.0 to 1.0
	// fraction of its adjustable range, so SceneManager can fill
	// the on-screen speed indicator without needing to know what
	// the speed limits are
	// (added by Matthew Randall, August 2026)
	static float GetCameraSpeedFraction();

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// active OpenGL display window
	GLFWwindow* m_pWindow;

	// process keyboard events for interaction with the 3D scene
	void ProcessKeyboardEvents();

public:
	// create the initial OpenGL display window
	GLFWwindow* CreateDisplayWindow(const char* windowTitle);
	
	// prepare the conversion from 3D object display to 2D scene display
	void PrepareSceneView();
};

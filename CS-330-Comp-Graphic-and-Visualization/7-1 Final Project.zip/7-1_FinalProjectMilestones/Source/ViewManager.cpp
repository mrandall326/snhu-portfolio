///////////////////////////////////////////////////////////////////////////////
// ViewManager.cpp
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MODIFIED BY: Matthew Randall
//  Course: CS 330 - Computational Graphics and Visualization
//  Date: July 22, 2026
//  Milestone Three: Implemented full camera navigation for the 3D
//  scene:
//    - WASD keys move the camera forward/backward/left/right
//    - Q/E keys move the camera up/down
//    - Mouse movement orients the camera (look up/down/left/right)
//    - Mouse scroll wheel adjusts the camera movement speed,
//      shown on the speed indicator bar drawn by SceneManager
//    - P key switches to perspective projection; O key switches to
//      orthographic projection, without moving the camera
//
//  Date: August 12, 2026
//  Changed the P and O keys to switch the projection matrix only.
//  They previously also snapped the camera back to a fixed
//  position and angle, which threw away wherever the user had
//  navigated to and made the two projections impossible to compare
//  against the same view.
//
//  Added GetCameraSpeedFraction(), which reports the camera's
//  current movement speed as a fraction of its adjustable range.
//  SceneManager uses it to fill the on-screen speed indicator. The
//  conversion lives here because the speed limits are defined in
//  this file, so retuning them changes nothing elsewhere.
//
//  Student modifications: Mouse_Position_Callback(),
//  Mouse_Scroll_Callback() (new), GetCameraSpeedFraction() (new),
//  ProcessKeyboardEvents(), PrepareSceneView() projection
//  handling, and camera/scroll setup in the constructor and
//  CreateDisplayWindow().
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between the current frame and the last frame, in
	// seconds - multiplying movement by this value makes camera
	// speed independent of frame rate (a fast PC rendering 200
	// frames per second moves the camera the same distance per
	// second as a slow PC rendering 30)
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;

	// limits for the camera movement speed, which the user can
	// adjust with the mouse scroll wheel - clamping keeps the
	// speed usable (never zero/negative, never uncontrollable)
	const float CAMERA_SPEED_MIN = 0.5f;
	const float CAMERA_SPEED_MAX = 20.0f;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80;
	// initialize the yaw/pitch angles to match the default Front
	// vector above - without this, the first mouse movement would
	// snap the view back to the camera's internal default angles.
	// Yaw of -90 degrees points the camera down the -Z axis
	// (toward the scene), and pitch of -14 degrees angles it
	// slightly downward, matching the (0, -0.5, -2) Front vector
	g_pCamera->Yaw = -90.0f;
	g_pCamera->Pitch = -14.0f;
	// starting movement speed - adjustable with the scroll wheel
	g_pCamera->MovementSpeed = 6.0f;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events - the cursor is hidden
	// and locked to the window so mouse movement can continuously
	// orient the camera (Milestone Three requirement)
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// this callback is used to receive mouse scroll wheel events,
	// which adjust the camera movement speed
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  Implemented by: Matthew Randall
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 *  The change in cursor position since the last frame is
 *  converted into a camera orientation change, letting the
 *  user look up/down and left/right.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// on the very first mouse event, sync the last-position
	// variables to the current cursor position - otherwise the
	// first movement would produce one large, jarring jump
	if (gFirstMouse)
	{
		gLastX = (float)xMousePos;
		gLastY = (float)yMousePos;
		gFirstMouse = false;
	}

	// calculate how far the cursor moved since the last event
	float xOffset = (float)xMousePos - gLastX;
	// reversed: screen Y coordinates increase downward, but a
	// downward mouse movement should pitch the camera down
	float yOffset = gLastY - (float)yMousePos;

	// remember the current position for the next event
	gLastX = (float)xMousePos;
	gLastY = (float)yMousePos;

	// pass the offsets to the camera object, which applies its
	// mouse sensitivity and updates the yaw/pitch orientation
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  Implemented by: Matthew Randall
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse scroll wheel is moved. Scrolling up increases
 *  the camera movement speed and scrolling down decreases
 *  it, clamped to a usable range.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	// adjust the movement speed by the vertical scroll amount
	g_pCamera->MovementSpeed += (float)yOffset;

	// clamp the speed so it can never become zero, negative,
	// or uncontrollably fast
	if (g_pCamera->MovementSpeed < CAMERA_SPEED_MIN)
	{
		g_pCamera->MovementSpeed = CAMERA_SPEED_MIN;
	}
	if (g_pCamera->MovementSpeed > CAMERA_SPEED_MAX)
	{
		g_pCamera->MovementSpeed = CAMERA_SPEED_MAX;
	}
}

/***********************************************************
 *  GetCameraSpeedFraction()
 *
 *  Implemented by: Matthew Randall
 *
 *  Reports where the camera's current movement speed sits
 *  within its adjustable range, as a fraction from 0.0 at the
 *  minimum to 1.0 at the maximum. SceneManager uses this to
 *  fill the on-screen speed indicator.
 *
 *  The conversion is done here rather than in the scene code
 *  because the speed limits are defined in this file. A caller
 *  only has to know that the value it gets back is a fraction,
 *  so retuning the limits changes nothing outside this class.
 ***********************************************************/
float ViewManager::GetCameraSpeedFraction()
{
	// no camera means nothing to report - return the minimum so
	// the indicator draws as empty rather than reading garbage
	if (NULL == g_pCamera)
	{
		return 0.0f;
	}

	float fraction =
		(g_pCamera->MovementSpeed - CAMERA_SPEED_MIN) /
		(CAMERA_SPEED_MAX - CAMERA_SPEED_MIN);

	// the scroll callback already clamps the speed, so this is a
	// guard against a future change to that clamp rather than a
	// condition the current code can reach
	if (fraction < 0.0f)
	{
		fraction = 0.0f;
	}
	if (fraction > 1.0f)
	{
		fraction = 1.0f;
	}

	return fraction;
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  Modified by: Matthew Randall
 *
 *  This method is called once per frame to process any
 *  keyboard events that may be waiting in the event queue.
 *
 *  Keyboard controls implemented for Milestone Three:
 *    W/S - move the camera forward/backward (depth)
 *    A/D - move the camera left/right (horizontal)
 *    Q/E - move the camera up/down (vertical)
 *    P   - switch to perspective (3D) projection
 *    O   - switch to orthographic (2D) projection
 *          (both change the projection only - the camera stays
 *           where the user left it)
 *    ESC - close the application window
 *
 *  Keys are polled with glfwGetKey rather than handled in a
 *  key callback so that held-down keys produce continuous,
 *  smooth movement every frame instead of single steps.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// if the camera object is not valid, no navigation is possible
	if (NULL == g_pCamera)
	{
		return;
	}

	/*** WASD keys - horizontal and depth navigation             ***/
	// each call moves the camera by MovementSpeed * gDeltaTime,
	// so movement is smooth and frame-rate independent
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		// move forward, into the scene
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		// move backward, away from the scene
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		// strafe left
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		// strafe right
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}

	/*** Q/E keys - vertical navigation                          ***/
	// implemented by moving the camera position directly along
	// its Up vector, using the same speed * deltaTime velocity
	// as the WASD movement for a consistent feel
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		// move upward
		g_pCamera->Position +=
			g_pCamera->MovementSpeed * gDeltaTime * g_pCamera->Up;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		// move downward
		g_pCamera->Position -=
			g_pCamera->MovementSpeed * gDeltaTime * g_pCamera->Up;
	}

	/*** P/O keys - projection mode switching                    ***/
	// these switch ONLY the projection matrix used to draw the
	// scene. The camera's position and orientation are deliberately
	// left untouched, so whatever the user is looking at stays in
	// front of them and the two projections can be compared against
	// the same view - pressing O shows the same framing drawn
	// without perspective foreshortening, rather than jumping to
	// some other part of the room
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		// switch to 3D perspective projection
		bOrthographicProjection = false;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		// switch to 2D orthographic projection
		bOrthographicProjection = true;
	}
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  Modified by: Matthew Randall
 *
 *  This method is called once per frame to process input
 *  events, then build the current view and projection
 *  matrices and pass them into the shader. The projection
 *  matrix is either perspective (3D) or orthographic (2D),
 *  depending on which mode the user selected with the
 *  P and O keys.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// define the current projection matrix based on the
	// user-selected projection mode
	if (bOrthographicProjection)
	{
		// orthographic (2D) projection - a parallel projection
		// with no perspective foreshortening, so objects stay the
		// same size regardless of distance from the camera. The
		// six values define a rectangular box-shaped view volume
		// in world units, centered on the camera: 20 units wide
		// and 16 units tall, which is wide enough to hold the
		// whole desk at the default view and matches the window's
		// 1000x800 (10:8) aspect ratio so the scene is not
		// stretched. What is actually framed depends on where the
		// user has moved the camera, since switching projection no
		// longer moves it
		projection = glm::ortho(
			-10.0f, 10.0f,    // left, right edges of view volume
			-8.0f, 8.0f,      // bottom, top edges of view volume
			0.1f, 100.0f);    // near, far clipping distances
	}
	else
	{
		// perspective (3D) projection - objects farther from the
		// camera appear smaller, giving the scene realistic depth
		projection = glm::perspective(glm::radians(g_pCamera->Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the projection matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}

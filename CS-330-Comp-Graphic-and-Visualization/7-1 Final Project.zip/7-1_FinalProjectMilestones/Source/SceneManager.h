///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MODIFIED BY: Matthew Randall
//  Course: CS 330 - Computational Graphics and Visualization
//  Date: July 13, 2026
//  Milestone Two: Added private helper method declarations
//  (RenderDeskSurface, RenderMonitor) to modularize the scene
//  rendering code in SceneManager.cpp.
//
//  Date: July 29, 2026
//  Milestone Four: Added the LoadSceneTextures() declaration,
//  which loads and tags the image files used to texture the scene.
//
//  Date: August 5, 2026
//  Completed the desk scene by declaring a render helper for each
//  remaining object: RenderKeyboard, RenderMousePad, RenderMouse,
//  RenderGizmoFigurine, RenderGoombaFigurine, RenderDeskLamp, and
//  RenderTumbler. The two figurines get a method each rather than
//  sharing one, both because the instructor feedback asked for them
//  to be modeled as separate distinct objects and because they no
//  longer share any geometry. Following the same one-method-per-
//  object pattern established in Milestone Two keeps RenderScene()
//  readable now that the scene holds nine objects instead of two.
//
//  Date: August 6, 2026
//  Milestone Five: Added the DefineObjectMaterials() and
//  SetupSceneLights() declarations. The two are kept as separate
//  methods, and separate from the render code, because they set
//  scene state that never changes from frame to frame: both are
//  called once from PrepareScene() rather than from RenderScene().
//  SetupSceneLights() defines four sources: the desk lamp, a
//  window, a ceiling fluorescent, and the monitor's own screen
//  glow.
//
//  Date: August 12, 2026
//  Added the RenderSpeedIndicator() declaration, which draws the
//  2D on-screen camera speed bar over the finished 3D scene. It is
//  grouped with the other render helpers because RenderScene()
//  calls it the same way, even though what it draws is a readout
//  rather than an object in the room.
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager *pShaderManager);
	// destructor
	~SceneManager();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures;
	// loaded textures info
	TEXTURE_INFO m_textureIDs[16];
	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	// free the loaded OpenGL textures
	void DestroyGLTextures();
	// find a loaded texture by tag
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	// find a defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	// set the transformation values 
	// into the transform buffer
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(
		std::string textureTag);

	// set the UV scale for the texture mapping
	void SetTextureUVScale(
		float u, float v);

	// set the object material into the shader
	void SetShaderMaterial(
		std::string materialTag);

public:

	// The following methods are for the students to 
	// customize for their own 3D scene
	void PrepareScene();
	void RenderScene();

private:
	// loads the image files used to texture the scene and binds
	// them to their OpenGL texture slots
	// (added by Matthew Randall for Milestone Four)
	void LoadSceneTextures();

	// defines the surface materials that control how each object
	// reflects light, and positions the scene's four light sources
	// (added by Matthew Randall for Milestone Five)
	void DefineObjectMaterials();
	void SetupSceneLights();

	// helper methods for rendering each object in the 3D scene -
	// one method per object keeps RenderScene() short and modular
	// (pattern established by Matthew Randall in Milestone Two)
	void RenderDeskSurface();
	void RenderMonitor();

	// the rest of the desk, each object built from several
	// transformed primitives and following the same pattern
	// (added by Matthew Randall, August 2026)
	void RenderKeyboard();
	void RenderMousePad();
	void RenderMouse();
	void RenderGizmoFigurine();
	void RenderGoombaFigurine();
	void RenderDeskLamp();
	void RenderTumbler();
	// draws the 2D on-screen camera speed indicator over the
	// finished 3D scene - not an object in the room, so it is
	// drawn unlit and sets no material
	// (added by Matthew Randall, August 2026)
	void RenderSpeedIndicator();

};

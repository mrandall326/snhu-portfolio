///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MODIFIED BY: Matthew Randall
//  Course: CS 330 - Computational Graphics and Visualization
//
//  Date: July 14, 2026
//  Milestone Two: Replicates the computer monitor from my Milestone
//  One reference photo as a complex 3D object built from four
//  transformed basic shapes: a cylinder, a tapered cylinder, and
//  two boxes. (The stand neck started as a straight cylinder and
//  became a tapered one in Milestone Four.) Scene rendering is
//  modularized into per-object helper methods (RenderDeskSurface,
//  RenderMonitor) declared in SceneManager.h.
//
//  Date: July 29, 2026
//  Milestone Four: Applied textures to the scene.
//    - Added LoadSceneTextures(), which loads four image files and
//      tags them for the render methods to select by name
//    - Applied four different textures across the monitor's four
//      shapes (circular brushed stainless on the base, matte
//      charcoal at two different zoom levels on the neck and
//      bezel, and a screen capture on the display) so each
//      component reads as its real-world material
//    - Controlled every texture's UV scale with SetTextureUVScale():
//      tiled the desk and neck to keep their patterns at a
//      believable scale, zoomed into the dark corner of the bezel
//      texture with a scale below 1, and deliberately left the base
//      and the display face at 1:1
//    - Replaced the stand neck's straight cylinder with a tapered
//      cylinder tilted forward into the back of the screen panel,
//      correcting a visible gap where the neck previously ended in
//      mid-air below the panel
//    - Added DestroyGLTextures() to the destructor so the loaded
//      textures are released from GPU memory on shutdown
//
//  Date: August 5, 2026
//  Completed the desk scene ahead of the lighting milestone by
//  adding the remaining objects from my Milestone One reference
//  photo, each in its own helper method:
//    - RenderKeyboard()       - the black case and gray key plate
//                               of my board, with all 106 keycaps
//                               placed individually from a layout
//                               table measured in key units, so
//                               the grid of gaps that identifies
//                               a keyboard actually reads
//    - RenderMousePad()       - a cloth pad, two boxes so the
//                               stitched border shows
//    - RenderMouse()          - the Redragon from my desk: two
//                               spheres of different sizes
//                               tapering a short broad palm hump
//                               down to a long low nose, split
//                               main buttons with the wheel in
//                               the channel between them, a thumb
//                               flare, and gray trim - skirt,
//                               logo plate, DPI pads and thumb
//                               switch - so the shell does not
//                               read as one solid black lump
//    - RenderGizmoFigurine()  - a mogwai, modeled from a photo of
//                               the figure on my shelf: brown
//                               shapes with white ones set into
//                               their fronts to carry the two
//                               tone fur, oversized head, and
//                               ears angled up and out
//    - RenderGoombaFigurine() - a Goomba, its pear shaped head
//                               built from two spheres of
//                               different widths, with the angled
//                               brows and the fangs that separate
//                               it from a plain mushroom
//    - RenderDeskLamp()       - an articulated Pixar style lamp
//                               whose joint positions are
//                               CALCULATED from its arm angles
//                               rather than hard coded, so
//                               retuning an angle moves the
//                               whole arm above it
//    - RenderTumbler()        - my Pokeball tumbler: a white cup
//                               with a cone tapering it down to
//                               a narrow foot, a smoked lid,
//                               straw, and side handle, with the
//                               Pokeball built as a raised
//                               medallion on the front, whose red
//                               half is a stack of boxes fitted to
//                               the arc by the circle equation
//                               because no loaded mesh draws a
//                               half circle
//  Loaded the sphere and cone meshes in PrepareScene() to support
//  the new shapes, and used SetShaderColor() on the objects whose
//  real finish - fur, painted resin, Pokeball red, keycap cream -
//  is not represented by any of the four loaded textures.
//
//  Date: August 6, 2026
//  Milestone Five: Applied lighting to the scene.
//    - Added DefineObjectMaterials(), which defines the eight
//      surface materials used in the scene. A material controls
//      how a surface RESPONDS to light, separately from the
//      texture or flat color that gives it its color, so the
//      brushed steel of the lamp, the cloth of the mouse pad,
//      and the glossy shell of the mouse all shade differently
//      under the same lights
//    - Added SetupSceneLights(), which enables lighting in the
//      shader and positions FOUR light sources, each one
//      motivated by something actually present in the room:
//      the desk lamp's own bulb, warm and close and standing
//      in for a spotlight aimed at the keyboard; daylight from
//      a window off to the left and outside the frame; a
//      ceiling fluorescent set high and well behind the
//      camera on the right, over the shoulder of someone
//      seated at the desk; and the cool light the monitor's
//      own screen throws forward onto the keyboard and the
//      desk in front of it. Nothing is placed directly above
//      the desk, since a light straight overhead lands evenly
//      on every horizontal surface at once and flattens the
//      desktop into a single tone. The warm lamp on the left,
//      the cool window and fluorescent on the far left and
//      behind, and the cooler screen light from the center
//      back light every object from at least two directions
//      in two different color temperatures, and the four
//      positions between them leave no face of any object in
//      complete shadow
//    - Applied a material to every shape of the scene's objects
//      with SetShaderMaterial(), alongside the texture or the
//      color that shape already set - including the desk slab,
//      whose wood material is what reflects the lights off the
//      desktop
//    - Drew the two objects in the scene that EMIT light - the
//      monitor's display face and the lamp's bulb - with
//      lighting switched off, since no material can describe a
//      surface that produces its own brightness. Running the
//      wallpaper through the lighting model clipped its bright
//      areas to white while the ambient term lifted its blacks
//      to gray, and the bulb, which has light source [0]
//      sitting inside it and therefore receives no diffuse
//      from it at all, came out darker than the desk it lights
//    - Weighted the desk lamp at roughly twice the diffuse of
//      either fill light and held every ambient value low, so
//      that the pool of light the lamp lays across the desk is
//      visible instead of being filled in by the room. Three
//      sources of equal strength light a scene without putting
//      any light in it
//    - Gave the bulb a glow, built from three additively
//      blended spheres of increasing size and decreasing
//      brightness stacked around it. Additive blending adds
//      what is drawn to what is already in the frame instead
//      of replacing it, which is what light does, and it is
//      the only way to produce a halo with no hard edge out of
//      meshes that all have hard edges. The blend mode, the
//      depth mask and the lighting flag are all restored
//      immediately afterward, since all three are global
//      state
//    - Called both new methods once from PrepareScene() rather
//      than from RenderScene(), since neither changes from
//      frame to frame
//
//  Date: August 12, 2026
//  Added RenderSpeedIndicator(), an on-screen bar that fills and
//  drains with the camera's movement speed as the scroll wheel is
//  turned. The speed has been adjustable since Milestone Three but
//  invisible while it changed, so the wheel gave no feedback until
//  the user moved and compared. The bar is drawn from the same box
//  mesh as the rest of the scene, in a short pass that puts the
//  shader into screen coordinates with an orthographic projection
//  and an identity view, and switches off lighting and depth
//  testing so the readout sits over the scene at a fixed place on
//  the window. All three settings are restored before the method
//  returns. The bar is labeled "CAMERA SPEED", set sideways along
//  its outer edge and built the same way as everything else in the
//  scene: the program has no text rendering, so each letter is a
//  3 by 5 grid of pixels and every lit pixel is one small box.
//
//  Student modifications: LoadSceneTextures(),
//  DefineObjectMaterials(), SetupSceneLights(), PrepareScene(),
//  RenderScene(), RenderDeskSurface(), RenderMonitor(),
//  RenderKeyboard(), RenderMousePad(), RenderMouse(),
//  RenderGizmoFigurine(), RenderGoombaFigurine(),
//  RenderDeskLamp(), RenderTumbler(), RenderSpeedIndicator(),
//  and the texture cleanup call in the destructor. All other
//  methods are unchanged instructor-provided code.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// used for the trigonometry the scene's placement math relies on -
// turning an angle into a direction vector for the tilted screen's
// forward facing and for the desk lamp's arm and shade angles, and
// solving the circle equation for the width of each bar in the
// tumbler's emblem (added by Matthew Randall)
#include <cmath>

// the on-screen speed indicator reads the camera's current
// movement speed through ViewManager's accessor (added by
// Matthew Randall)
#include "ViewManager.h"

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
	// the view and projection matrices are normally owned by
	// ViewManager, which sets them once per frame. RenderSpeedIndicator()
	// overrides them for its 2D overlay pass, so it needs their
	// names here as well (added by Matthew Randall)
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	// release the scene's textures from GPU memory when the
	// application shuts down (added by Matthew Randall for
	// Milestone Four - the textures are loaded in
	// LoadSceneTextures(), so they are freed here)
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  LoadSceneTextures()
 *
 *  Implemented by: Matthew Randall
 *
 *  Loads every image file used by the scene into GPU texture
 *  memory and binds it to a texture slot, ready for the
 *  render methods to select by tag.
 *
 *  Each call to CreateGLTexture() reads one image file and
 *  associates it with a short string tag. The render methods
 *  then request a texture by that tag instead of by file
 *  name, so a texture can be swapped out later by editing
 *  one line here rather than hunting through the drawing
 *  code. BindGLTextures() is called once at the end to bind
 *  all of the loaded textures to their OpenGL texture slots.
 *
 *  All file paths are RELATIVE to the project directory,
 *  which is the working directory the application runs from,
 *  so the scene loads correctly on any machine using the
 *  standard CS330Content folder structure.
 *
 *  Three of the four images ship with the course and are read
 *  from ../../Utilities/textures. The screen capture is not a
 *  course texture, so it is stored in a "textures" folder
 *  inside the project directory and travels with the project
 *  when it is zipped for submission.
 *
 *  Not every object in the scene draws from this list. The
 *  keycaps and their plate, the mouse and its pad, both
 *  figurines, the lamp's joints, and the tumbler are given
 *  flat colors with SetShaderColor() instead - either because
 *  their real finish is not represented by any of the four
 *  hard surface images loaded here, or because the object is
 *  too small for an image to sample to anything but a blur.
 *
 *  The lamp's SHADE does draw from this list: it takes the
 *  same brushed steel as the lamp's base and arms, so the lamp
 *  reads as one piece of hardware rather than as a painted
 *  head on a metal stand.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// tracks whether EVERY texture loaded successfully. A missing
	// or misnamed image file is the most common cause of an
	// untextured (solid black or white) object, so each result is
	// folded into this flag rather than discarded. CreateGLTexture()
	// already reports each file it fails on; the flag is what turns
	// those individual lines into one summary at the end, so a
	// failure is visible without reading back through the log
	bool bTextureLoaded = true;

	// wood grain for the desk surface slab
	bTextureLoaded = CreateGLTexture(
		"../../Utilities/textures/rusticwood.jpg", "desk") && bTextureLoaded;

	// circular brushed stainless, used for the round monitor base
	// and for every part of the desk lamp - base, arms, and shade.
	// The radial brushing pattern of this image suits a disc, which
	// is why it is left untiled on the two round bases and on the
	// shade; on the lamp's thin arms it is repeated up their length
	// instead, so the brushing is not stretched into streaks
	bTextureLoaded = CreateGLTexture(
		"../../Utilities/textures/stainless_end.jpg", "baseMetal") && bTextureLoaded;

	// dark studio backdrop, used for the large matte black surfaces
	// in the scene - the monitor's neck and bezel and the keyboard
	// case. The real hardware is matte black, and the shadowed
	// corner of this image is a near-black charcoal with a faint
	// mottling that reads convincingly as textured black plastic
	// (see the UV note in RenderMonitor). It is NOT used on the
	// mouse: over a shape that small the mottling sampled to a
	// brown blotch and made the object look like wood
	bTextureLoaded = CreateGLTexture(
		"../../Utilities/textures/background.jpg", "bezel") && bTextureLoaded;

	// a screen capture of my actual desktop, shown on the
	// monitor's display face. Using the real desktop rather than
	// just the wallpaper keeps the icons and taskbar in frame,
	// which makes the monitor read as powered on instead of as a
	// framed picture. This is the only image not supplied with
	// the course, so it is stored inside the project folder and
	// travels with the submission
	bTextureLoaded = CreateGLTexture(
		"textures/space_wallpaper.png", "screen") && bTextureLoaded;

	// report the combined result once. An object whose texture failed
	// to load still draws - it simply draws untextured - so without
	// this line a bad path shows up as a mysteriously blank surface
	// rather than as an error
	if (bTextureLoaded == false)
	{
		std::cout << "One or more scene textures failed to load - check "
			<< "the paths reported above; the affected objects will "
			<< "render untextured." << std::endl;
	}

	// bind all of the loaded textures to their texture slots
	// so the shader can sample from them during rendering
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Implemented by: Matthew Randall
 *
 *  Defines the surface materials used by the objects in the
 *  scene. A material describes how a surface RESPONDS to
 *  light, which is a separate question from what color that
 *  surface is: the texture or the flat color set in each
 *  render method supplies the color, and the material set
 *  alongside it decides whether that color comes back as a
 *  broad soft sheen, a tight bright highlight, or nothing at
 *  all.
 *
 *  Each material is pushed onto the materials list with a
 *  short string tag, and the render methods select one by tag
 *  with SetShaderMaterial() immediately before drawing, the
 *  same way they select a texture. Defining them in one place
 *  means every steel part in the scene reflects light
 *  identically, and retuning the steel is a single edit here
 *  rather than a hunt through eight draw calls.
 *
 *  THE THREE PHONG TERMS, and what each one is doing below:
 *
 *    ambientColor / ambientStrength - the light a surface
 *      keeps when no light source reaches it. Held LOW on
 *      every material here, and deliberately so: ambient is
 *      the term that reaches a surface no matter where the
 *      lights are, so it is also the term that flattens a
 *      scene. Raising it lifts the shadowed side of every
 *      object at once, which is exactly what makes a lit room
 *      stop looking lit - the objects go on being visible, but
 *      nothing looks like it is coming from anywhere.
 *
 *    diffuseColor - the base shading, spread evenly across a
 *      surface according to its angle to the light. Kept high
 *      on every material, because the images and flat colors
 *      it multiplies against are already mid tone; darkening
 *      it here as well would double up and leave the scene
 *      muddy.
 *
 *    specularColor / shininess - the highlight. This is where
 *      the materials actually differ from one another, and
 *      it is what carries the difference between the finishes
 *      on a desk full of hardware: a high specular with a
 *      high shininess concentrates the highlight into the
 *      small bright spot that reads as polished steel, while
 *      a near zero specular with a low shininess spreads it
 *      out until it disappears, which is what cloth does.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	/*** WOOD - the desk slab.                                      ***/
	/*** A satin finished desktop is not glossy, but it is not dead ***/
	/*** either. A modest specular at a low shininess gives it the  ***/
	/*** wide, soft band of sheen that a wooden top shows under a   ***/
	/*** light rather than a mirror like spot.                      ***/
	/***                                                            ***/
	/*** The DIMMEST diffuse of any material in the scene, and      ***/
	/*** deliberately so. The desktop is a large upward facing      ***/
	/*** surface, so it catches something from every light in the   ***/
	/*** room, and the image on it is an already saturated orange   ***/
	/*** wood grain. Set as bright as the objects standing on it,   ***/
	/*** the slab clipped to a flat orange with the grain washed    ***/
	/*** out of it. Its blue channel is also lifted closer to its   ***/
	/*** red than the raw image, which pulls some of that           ***/
	/*** saturation back out.                                       ***/
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.26f, 0.23f, 0.20f);
	woodMaterial.ambientStrength = 0.24f;
	woodMaterial.diffuseColor = glm::vec3(0.62f, 0.60f, 0.58f);
	woodMaterial.specularColor = glm::vec3(0.16f, 0.15f, 0.14f);
	woodMaterial.shininess = 10.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	/*** BRUSHED METAL - the monitor base, the keyboard's mounting  ***/
	/*** plate, the mouse's trim details, and every part of the     ***/
	/*** desk lamp.                                                 ***/
	/*** The strongest specular in the scene at a high shininess,   ***/
	/*** which is what pulls a bright rim along the curve of the    ***/
	/*** monitor base and up the lamp's arms and tells the eye they ***/
	/*** are metal and not gray paint.                              ***/
	OBJECT_MATERIAL brushedMetalMaterial;
	brushedMetalMaterial.ambientColor = glm::vec3(0.28f, 0.29f, 0.32f);
	brushedMetalMaterial.ambientStrength = 0.22f;
	brushedMetalMaterial.diffuseColor = glm::vec3(0.80f, 0.82f, 0.86f);
	brushedMetalMaterial.specularColor = glm::vec3(0.75f, 0.77f, 0.82f);
	brushedMetalMaterial.shininess = 48.0f;
	brushedMetalMaterial.tag = "brushedMetal";
	m_objectMaterials.push_back(brushedMetalMaterial);

	/*** MATTE PLASTIC - the monitor's neck and bezel, the keyboard ***/
	/*** case, both figurine bases, and the tumbler's handle and    ***/
	/*** the dark parts of its emblem.                              ***/
	/*** Almost no specular. The black plastic on real hardware is  ***/
	/*** deliberately non reflective so it does not throw glare      ***/
	/*** back at the person using it, and letting these parts stay  ***/
	/*** flat is also what keeps the monitor's bezel from competing ***/
	/*** with the display inside it.                                ***/
	OBJECT_MATERIAL mattePlasticMaterial;
	mattePlasticMaterial.ambientColor = glm::vec3(0.22f, 0.22f, 0.24f);
	mattePlasticMaterial.ambientStrength = 0.30f;
	mattePlasticMaterial.diffuseColor = glm::vec3(0.82f, 0.82f, 0.84f);
	mattePlasticMaterial.specularColor = glm::vec3(0.10f, 0.10f, 0.11f);
	mattePlasticMaterial.shininess = 6.0f;
	mattePlasticMaterial.tag = "mattePlastic";
	m_objectMaterials.push_back(mattePlasticMaterial);

	/*** GLOSSY PLASTIC - the mouse shell and its buttons, both      ***/
	/*** figurines' eyes, the Goomba's fangs, and the tumbler's cup, ***/
	/*** lid, straw and emblem faces.                                ***/
	/*** This material is doing the most work of any in the scene.   ***/
	/*** Every object it is applied to is a CURVED shape drawn in a  ***/
	/*** single flat color, and a curved surface with no highlight   ***/
	/*** on it reads as a silhouette rather than as a solid - the    ***/
	/*** black mouse in particular looked like a hole cut in the pad ***/
	/*** until it had a highlight to travel across its shell.        ***/
	OBJECT_MATERIAL glossyPlasticMaterial;
	glossyPlasticMaterial.ambientColor = glm::vec3(0.24f, 0.24f, 0.26f);
	glossyPlasticMaterial.ambientStrength = 0.26f;
	glossyPlasticMaterial.diffuseColor = glm::vec3(0.85f, 0.85f, 0.86f);
	glossyPlasticMaterial.specularColor = glm::vec3(0.55f, 0.55f, 0.58f);
	glossyPlasticMaterial.shininess = 40.0f;
	glossyPlasticMaterial.tag = "glossyPlastic";
	m_objectMaterials.push_back(glossyPlasticMaterial);

	/*** KEYCAP - all 106 caps on the keyboard.                     ***/
	/*** Moulded keycaps are lightly textured rather than polished, ***/
	/*** so this sits between the matte and glossy plastics: enough ***/
	/*** highlight to catch the top edge of each cap, which is what ***/
	/*** separates one cap from the next across a field of over a   ***/
	/*** hundred boxes of the same color, but not enough to make    ***/
	/*** the board look wet.                                        ***/
	OBJECT_MATERIAL keycapMaterial;
	keycapMaterial.ambientColor = glm::vec3(0.26f, 0.26f, 0.26f);
	keycapMaterial.ambientStrength = 0.30f;
	keycapMaterial.diffuseColor = glm::vec3(0.88f, 0.88f, 0.88f);
	keycapMaterial.specularColor = glm::vec3(0.22f, 0.22f, 0.22f);
	keycapMaterial.shininess = 16.0f;
	keycapMaterial.tag = "keycap";
	m_objectMaterials.push_back(keycapMaterial);

	/*** CLOTH - the mouse pad, both the border and the surface.    ***/
	/*** The only material in the scene with its specular set to    ***/
	/*** effectively zero. Woven fabric scatters light in every     ***/
	/*** direction instead of reflecting it in one, so it never     ***/
	/*** shows a highlight, and that total absence is exactly what  ***/
	/*** distinguishes the pad from the desk it lies on - the two   ***/
	/*** are both flat horizontal surfaces catching the same        ***/
	/*** overhead light, so shape and shading cannot tell them      ***/
	/*** apart, but their response to that light can.               ***/
	OBJECT_MATERIAL clothMaterial;
	clothMaterial.ambientColor = glm::vec3(0.20f, 0.21f, 0.26f);
	clothMaterial.ambientStrength = 0.32f;
	clothMaterial.diffuseColor = glm::vec3(0.80f, 0.80f, 0.84f);
	clothMaterial.specularColor = glm::vec3(0.02f, 0.02f, 0.02f);
	clothMaterial.shininess = 2.0f;
	clothMaterial.tag = "cloth";
	m_objectMaterials.push_back(clothMaterial);

	/*** RUBBER - the mouse's scroll wheel.                          ***/
	/*** One shape in the whole scene uses this, and it is worth its ***/
	/*** own material for that one shape: the wheel is the detail    ***/
	/*** that identifies the object as a mouse, and a scroll wheel   ***/
	/*** is a rubber tire sunk in a plastic channel. Making it the   ***/
	/*** dullest surface on an otherwise glossy shell is what makes  ***/
	/*** it visible down inside that channel.                        ***/
	OBJECT_MATERIAL rubberMaterial;
	rubberMaterial.ambientColor = glm::vec3(0.18f, 0.18f, 0.19f);
	rubberMaterial.ambientStrength = 0.28f;
	rubberMaterial.diffuseColor = glm::vec3(0.72f, 0.72f, 0.74f);
	rubberMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	rubberMaterial.shininess = 3.0f;
	rubberMaterial.tag = "rubber";
	m_objectMaterials.push_back(rubberMaterial);

	/*** PAINTED RESIN - both figurines, everything but their eyes  ***/
	/*** and their display bases.                                    ***/
	/*** A collectible figure is painted and then clear coated, so   ***/
	/*** it carries a soft sheen over its whole surface rather than  ***/
	/*** a hard spot in one place. The moderate shininess spreads    ***/
	/*** the highlight over a wide enough area to follow the curve   ***/
	/*** of a head or an ear, which is what keeps shapes this small  ***/
	/*** from flattening out.                                        ***/
	OBJECT_MATERIAL paintedResinMaterial;
	paintedResinMaterial.ambientColor = glm::vec3(0.26f, 0.24f, 0.22f);
	paintedResinMaterial.ambientStrength = 0.30f;
	paintedResinMaterial.diffuseColor = glm::vec3(0.86f, 0.84f, 0.82f);
	paintedResinMaterial.specularColor = glm::vec3(0.28f, 0.27f, 0.26f);
	paintedResinMaterial.shininess = 18.0f;
	paintedResinMaterial.tag = "paintedResin";
	m_objectMaterials.push_back(paintedResinMaterial);

	/*** NOTE: there is no material for the monitor's display face. ***/
	/*** A material describes how a surface REFLECTS light, and a   ***/
	/*** powered on display does not reflect the room - it emits    ***/
	/*** its own. It is drawn with lighting switched off instead,   ***/
	/*** which is explained where it is done, in RenderMonitor().   ***/

	/*** NOTE: there is no material for the lamp's bulb either, for ***/
	/*** the same reason as the display face. The two emitters in   ***/
	/*** the scene are both drawn with lighting switched off - see  ***/
	/*** the note at the bulb's draw call in RenderDeskLamp().      ***/
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Implemented by: Matthew Randall
 *
 *  Enables custom lighting in the shader and adds the FOUR
 *  light sources that illuminate the scene.
 *
 *  EVERY LIGHT HERE IS MOTIVATED BY THE ROOM. This scene is a
 *  desk in a real room, and a desk in a real room is lit by
 *  identifiable things, so rather than ring the scene with
 *  anonymous lamps, each source below stands in for a light
 *  that is actually present:
 *
 *    [0] Desk lamp - warm and close, positioned INSIDE the
 *        lamp's own bulb and aimed down and in toward the
 *        keyboard, the way the modeled shade points. This is
 *        the light that makes the scene read as a desk rather
 *        than as objects on a table.
 *
 *    [1] Window - daylight from a window off to the LEFT of
 *        the desk and outside the frame. No window is modeled;
 *        the light is simply placed far out on the -X axis at
 *        about the height a window sits, which is all it takes
 *        for the left faces of every object to pick up a broad
 *        even daylight while the right faces fall away.
 *
 *    [2] Ceiling fluorescent - the room fixture, set high and
 *        well BEHIND the camera on the right, over the
 *        shoulder of someone sitting at the desk. Nothing is
 *        placed directly above the desk on purpose: an
 *        overhead light straight up the Y axis lands almost
 *        evenly on every horizontal surface at once, which
 *        flattens the desktop into one flat tone and washes
 *        out the shading the other two lights are doing.
 *        Pushing it back and to the right instead means it
 *        rakes ACROSS the scene, filling the fronts and right
 *        sides that the window and the lamp cannot reach.
 *
 *    [3] Monitor glow - the light the screen itself throws.
 *        A powered on display is a large cool emitter, and
 *        this is the one source in the scene whose emitting
 *        surface is not only modeled but TEXTURED: the
 *        display face is drawn unlit in RenderMonitor()
 *        because it produces its own brightness, and this
 *        light is how that brightness reaches the rest of
 *        the room instead of stopping at the panel.
 *
 *        It is placed just IN FRONT of the display face,
 *        not inside or behind the panel. That distinction
 *        matters because the shader casts no shadows: a
 *        light set inside the panel is not blocked by it,
 *        so it would light the BACK faces of the keyboard
 *        and the figurines while a solid monitor stands
 *        visibly between them and the source. In front is
 *        also simply where a screen's light goes - onto the
 *        keycaps below it, the stretch of desk between the
 *        stand and the keyboard, and the inward facing
 *        sides of the two figurines flanking the base.
 *
 *  ON THE ABSENCE OF A TRUE SPOTLIGHT: the course shader
 *  implements point lights - each source has a position but no
 *  aim direction and no cone angle - so a real spotlight cone
 *  is not available to declare. The desk lamp is made to read
 *  as one by placement and by weighting instead: it is the
 *  closest source to the keyboard, it is the brightest and the
 *  most sharply focused of the four, and it is the only warm
 *  one, so the keycaps below it are lit noticeably harder and
 *  warmer than anything at the edges of the desk.
 *
 *  HOW THE LAMP GETS ITS FALLOFF, since the shader has no
 *  distance attenuation either. A light with no attenuation
 *  reaches the far corner of the desk as strongly as it
 *  reaches the keycap directly beneath it, which is why a
 *  lamp set to the same brightness as the room lights simply
 *  disappears into them - nothing about the render says the
 *  light came from that object rather than from anywhere else.
 *  What the shader does still give is the angle term: the
 *  brightness a surface receives falls off with the cosine of
 *  the angle between its normal and the direction to the
 *  light. For a flat desktop lit from a height h, that
 *  simplifies to h divided by the distance to the light, so a
 *  LOW, CLOSE source does produce a genuine pool. The bulb
 *  sits about 3.25 above the desk, which means a point one
 *  unit away from directly beneath it receives around 95
 *  percent of the lamp's light while a point ten units away
 *  receives around 31 percent - a real gradient across the
 *  desktop, and one that fades outward from the lamp exactly
 *  the way a pool of light should.
 *
 *  That gradient exists no matter how the lights are balanced.
 *  Whether it is VISIBLE is the part the balance controls,
 *  and it is why the three fill lights below are each set well
 *  under the lamp rather than to a brightness that looks
 *  correct on its own - together they still come to less than
 *  the lamp alone. Their light arrives from far enough away
 *  that its angle barely changes across the whole scene, so
 *  every unit of brightness they add is spread flat and even -
 *  which fills in the lamp's gradient and levels the desktop
 *  back out. Four sources of equal strength give a scene that
 *  is lit but has no light in it.
 *
 *  The monitor glow is the one fill that is NOT distant, and
 *  it earns its place for that reason: it sits close in over
 *  the middle of the desk, so like the lamp it lays down a
 *  gradient rather than a flat wash - a cool one, falling
 *  across the keyboard from the opposite side of the board to
 *  the lamp's warm one.
 *
 *  NOTHING IS IN COMPLETE SHADOW. The four positions cover
 *  four different sides of the room - close above on the left,
 *  far out to the left, high behind on the right, and close in
 *  at the center back - so every face of every object is
 *  angled toward at least one of them. The monitor glow in
 *  particular reaches the one region the other three cover
 *  worst: the faces turned back toward the screen, which the
 *  lamp is too far left to catch and the fluorescent behind
 *  the camera strikes at a glancing angle. Each light also
 *  carries a small ambient value that reaches surfaces no
 *  light faces at all, which lifts the undersides and the
 *  insides of shapes off pure black.
 *
 *  ON THE BRIGHTNESS AND SATURATION VALUES: the sources are
 *  SUMMED before the result is clamped, so a surface facing
 *  all four at once receives the total of all four
 *  contributions. The diffuse values are therefore set so that
 *  the total comes to roughly 0.7 on each channel rather than
 *  each light being set to a brightness that looks correct on
 *  its own, which clamps the desktop to a flat blown out
 *  orange and erases the wood grain the texture work was for.
 *  Adding the monitor glow did not raise that ceiling - it was
 *  paid for by trimming the window and the fluorescent, since
 *  a fourth source added on top of a budget already spent is
 *  just a brighter flatter scene. The one channel allowed to
 *  rise is BLUE, and only slightly, because a cool screen is
 *  the whole point of the source being there. For the
 *  same reason the lamp's warm tint is kept mild - its blue
 *  channel is lowered relative to its red, but not by much,
 *  because the wood texture it falls on is already a saturated
 *  orange and a strongly amber light multiplied against it
 *  pushes the desktop past what the display can show.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line is what tells the shader to light the scene with
	// the sources defined below instead of drawing every surface
	// at full brightness - without it, none of the values set in
	// this method have any effect on the render
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/******************************************************************/
	/*** LIGHT 0 - DESK LAMP (warm, the scene's brightest source)   ***/
	/*** The lamp on the desk, lit from inside its own bulb and     ***/
	/*** standing in for a spotlight aimed at the keyboard.         ***/
	/******************************************************************/
	// this position is the CALCULATED bulb position from
	// RenderDeskLamp(), worked out once here so the light sits
	// inside the shade rather than floating near it. The lamp's
	// arm chain resolves as follows, in scene units:
	//     shoulder  = (-6.30, 0.16, 1.20)
	//     elbow     = shoulder + 2.70 along  20 degrees = (-7.22, 2.70, 1.20)
	//     headJoint = elbow    + 2.40 along -45 degrees = (-5.53, 4.40, 1.20)
	//     bulb      = headJoint - 1.32 along  30 degrees = (-4.87, 3.25, 1.20)
	// The shade's 30 degree tilt points its open mouth down and to
	// the right from here, which is the direction the keyboard lies
	// in. If any of the lamp's angles or arm lengths are retuned,
	// this value has to be recalculated to match, or the lamp will
	// be lit from a point that is no longer inside it
	m_pShaderManager->setVec3Value("lightSources[0].position", -4.87f, 3.25f, 1.20f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.03f, 0.028f, 0.022f);
	// red highest and blue lowest, which is the incandescent cast
	// this lamp is meant to have - but only mildly, for the reason
	// given in the note on saturation above.
	//
	// This light carries roughly TWICE the diffuse of either of the
	// other two, and that ratio is the whole reason the lamp reads
	// as a light source at all rather than as an ornament. See the
	// note on falloff in the header: the lamp is the only source
	// close enough to the desk for its angle to change noticeably
	// across it, so it is the only one that can lay down a pool of
	// light, and a pool is only visible if it is brighter than what
	// surrounds it
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.46f, 0.39f, 0.30f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.85f, 0.76f, 0.60f);
	// focalStrength tightens the highlight and specularIntensity
	// controls how bright it is allowed to get. This is the
	// tightest, brightest highlight in the scene: a bare bulb close
	// to the objects is a small intense source, and a small source
	// is exactly what produces a hard specular spot, which is what
	// puts the glint on the tumbler and the figurines' eyes
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 48.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.20f);

	/******************************************************************/
	/*** LIGHT 1 - WINDOW (natural daylight from the left)          ***/
	/*** Placed far out on the -X axis and outside the frame, at    ***/
	/*** about the height of a window rather than up at the         ***/
	/*** ceiling. Nothing is modeled there; the light alone is      ***/
	/*** what suggests the window.                                  ***/
	/******************************************************************/
	// set well back from the desk so its direction barely changes
	// from one end of the scene to the other. That is what makes it
	// read as daylight rather than as a second lamp: sunlight
	// arrives in near parallel rays, so it lights the left face of
	// the tumbler on the far right at almost the same angle as the
	// left face of the lamp base, and a light placed close in would
	// instead fan out and give itself away
	m_pShaderManager->setVec3Value("lightSources[1].position", -24.0f, 9.0f, 1.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.022f, 0.024f, 0.030f);
	// near neutral with a faint blue lift, which is what daylight
	// is next to an incandescent bulb. The contrast against the
	// warm lamp is doing real work here - a surface turning from
	// warm on its lamp side to cool on its window side is visibly
	// turning even where its brightness hardly changes.
	//
	// held to well under a third of the lamp's strength. This is a
	// FILL light, and the job of a fill is to keep the shadowed
	// faces readable, not to light the scene. Set anywhere near the
	// lamp's value it does light the scene, and the lamp stops being
	// distinguishable from the room around it. Trimmed slightly from
	// its earlier value to make room in the total for the monitor
	// glow added as light [3]
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.13f, 0.14f, 0.16f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.30f, 0.32f, 0.36f);
	// a broad, weak highlight. A window is a LARGE emitting
	// surface, and large sources give wide gentle highlights rather
	// than the hard spot a bare bulb gives
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.05f);

	/******************************************************************/
	/*** LIGHT 2 - CEILING FLUORESCENT (over the right shoulder)    ***/
	/*** High on the ceiling, well behind the camera and off to     ***/
	/*** the right - roughly where a room fixture sits relative to  ***/
	/*** someone seated at this desk. Deliberately NOT above the    ***/
	/*** desk itself (see the note in the header above).            ***/
	/******************************************************************/
	// the large +Z puts it behind the default camera position, so
	// it lights the FRONT faces of the objects - the faces turned
	// toward the viewer, which the window on the left and the lamp
	// above cannot reach - and keeps them out of complete shadow
	m_pShaderManager->setVec3Value("lightSources[2].position", 13.0f, 17.0f, 20.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.018f, 0.022f, 0.020f);
	// a cool white with the faintest green lift, which is the cast
	// a fluorescent tube has and what separates it from the window
	// light on the opposite side. The dimmest of the four, and
	// trimmed further when the monitor glow was added, since the
	// two overlap in what they cover - but not removable: it is the
	// only source BEHIND the camera, so it is what keeps the faces
	// turned toward the viewer - the front of the keyboard case,
	// the fronts of both figurines, the near side of the tumbler -
	// out of complete shadow now that the ambient values are as low
	// as they are
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.08f, 0.09f, 0.085f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.22f, 0.25f, 0.24f);
	// the softest highlight of the four - a ceiling tube is a long
	// diffuse fixture, and it is far enough back that a hard spot
	// from it would only read as glare on the fronts of the objects
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 12.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.04f);

	/******************************************************************/
	/*** LIGHT 3 - MONITOR GLOW (cool, thrown by the screen)        ***/
	/*** The light the display itself puts into the room, placed    ***/
	/*** just in FRONT of the modeled display face and aimed, by    ***/
	/*** position alone, at the keyboard and the desk below it.     ***/
	/******************************************************************/
	// this position is DERIVED from the monitor's geometry the same
	// way light [0] is derived from the lamp's, rather than picked
	// by eye. RenderMonitor() centers the screen panel at (0, 5.0,
	// 0) and tilts it back 8 degrees, which turns the straight
	// ahead vector (0, 0, 1) into the panel's forward normal:
	//     panelForward = (0, -sin(-8), cos(-8)) = (0, 0.139, 0.990)
	// Stepping 1.2 units out along that normal from the panel's
	// center puts the light a little way off the glass:
	//     (0, 5.0, 0) + 1.2 * (0, 0.139, 0.990) = (0, 5.17, 1.19)
	// If the panel's center or its tilt is ever retuned, this value
	// has to be recalculated the same way, or the screen's light
	// will stop lining up with the screen
	//
	// IN FRONT OF THE PANEL, NOT INSIDE IT. The shader casts no
	// shadows, so a light placed inside the panel would not be
	// blocked by it - it would reach straight through and light the
	// BACK of the keyboard and the backs of both figurines, while a
	// solid monitor sits visibly between them and the source. In
	// front is also where a real screen's light actually goes
	m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, 5.17f, 1.19f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.010f, 0.012f, 0.018f);
	// the coolest source in the scene - blue highest, red lowest,
	// which is both what an LCD backlight is and what the space
	// wallpaper on this particular screen would throw. It is the
	// direct counterweight to the desk lamp: the two sit on
	// opposite sides of the keyboard in opposite color
	// temperatures, so a keycap between them is warm on its left
	// face and cool on the face turned back toward the screen -
	// which is what makes a field of identically colored boxes
	// read as having shape.
	//
	// The dimmest DIFFUSE of the four. A screen is bright to look
	// at but it is a poor room light, and pushing this any higher
	// tints the whole desk blue - the wood texture turns gray
	// before the glow on the keyboard becomes any more convincing
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.06f, 0.08f, 0.13f);
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.20f, 0.26f, 0.34f);
	// a wide, soft highlight. The display face is 8.3 by 4.7 units,
	// easily the largest emitting surface in the scene, and a large
	// source spreads its highlight out - a tight spot here would
	// read as a second bulb hanging in front of the monitor rather
	// than as the panel itself glowing
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 14.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.05f);
}

/***********************************************************
 *  PrepareScene()
 *
 *  Implemented by: Matthew Randall
 *
 *  This method is used for preparing the 3D scene by loading
 *  the textures, materials, lights, and shapes into memory to
 *  support the 3D scene rendering.
 *
 *  The order of the first three calls is deliberate. The
 *  textures have to be resident in GPU memory before anything
 *  samples from them, and the materials have to be defined
 *  before a render method can select one by tag. The lights
 *  are set up last of the three because they are the only
 *  setting here that has to be sent to the shader rather than
 *  stored in this class, and grouping that with the rest of
 *  the one time setup keeps the render loop free of it - all
 *  three are scene state that never changes from frame to
 *  frame, so doing this work once at startup rather than
 *  every frame is both correct and considerably faster.
 *
 *  Only one instance of each mesh type is loaded, no matter
 *  how many times that shape is drawn in the rendered scene.
 *  The five meshes below are reused heavily - the box alone is
 *  drawn around two hundred and fifty times a frame, since
 *  every one of the keyboard's keycaps, every bar of the
 *  tumbler's emblem, and every lit pixel of the speed
 *  indicator's label comes from the same loaded cube - and the
 *  sphere, cylinder, and cone each appear across several
 *  different objects. The tapered cylinder is drawn twice, for
 *  the monitor's stand neck and the lamp's shade.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the image files used to texture the scene - this is
	// done first so the textures are resident in GPU memory
	// before any object is drawn
	LoadSceneTextures();

	// define the surface materials the objects use to respond to
	// the scene's lighting, so the render methods can select one
	// by tag the same way they select a texture
	DefineObjectMaterials();

	// enable lighting in the shader and position the four light
	// sources that illuminate the scene
	SetupSceneLights();

	// cylinder mesh - the monitor base, the mouse scroll wheel,
	// both figurines' display bases, the Goomba's body, the lamp
	// base and arms, and the tumbler's sections, handle, straw,
	// and emblem discs
	m_basicMeshes->LoadCylinderMesh();

	// tapered cylinder mesh - the monitor stand neck, which narrows
	// as it rises into the back of the screen panel, and the desk
	// lamp's shade, which is the same truncated cone profile turned
	// to the job it was named for
	m_basicMeshes->LoadTaperedCylinderMesh();

	// box mesh - by far the most drawn shape in the scene: the desk
	// slab, the screen panel and display face, the keyboard case,
	// plate and all 106 of its keycaps, the two slabs of the mouse
	// pad and every button on the mouse, the Goomba's brows, and
	// every bar of the tumbler's emblem
	m_basicMeshes->LoadBoxMesh();

	// sphere mesh - the two spheres that taper the mouse shell and
	// the one that flares its thumb rest, nearly every part of both
	// figurines, the lamp's three joints and its bulb, and the
	// three blended shells that make up the bulb's glow
	m_basicMeshes->LoadSphereMesh();

	// cone mesh - the Gizmo figurine's ears, the Goomba's fangs,
	// and the shoulder that tapers the tumbler down to its foot
	m_basicMeshes->LoadConeMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  Implemented by: Matthew Randall
 *
 *  This method is used for rendering the 3D scene. The scene
 *  replicates my real desk setup from the Milestone One
 *  reference photo: a monitor, a keyboard, and a mouse on its
 *  pad, a Gizmo and a Goomba figurine, an articulated desk
 *  lamp, and my Pokeball tumbler, all standing on a wood desk
 *  slab.
 *
 *  Each object in the scene is rendered by its own private
 *  helper method to keep this method short and the code
 *  modular. Among the OBJECT calls the order does not affect
 *  what is drawn on top of what - the depth buffer sorts the
 *  geometry by distance no matter which order it arrives in -
 *  so those are listed by how they group on the desk instead:
 *  the surface and the monitor first, then the input devices in
 *  front of them - the mouse pad immediately before the mouse
 *  that stands on it - and finally the items placed around
 *  them.
 *
 *  RenderSpeedIndicator() is the exception, and it has to stay
 *  last. It draws the camera speed readout as a flat overlay
 *  with depth testing switched off, so unlike everything above
 *  it, it is layered by call order alone: anything drawn after
 *  it would paint straight over it.
 *
 *  LIGHTING: every shape of the scene's nine objects sets a
 *  material with SetShaderMaterial() alongside its texture or
 *  its color, which is what tells the shader how that surface
 *  should reflect the four light sources set up in
 *  SetupSceneLights(). The speed indicator is the one thing
 *  drawn here that sets no material, because it is drawn unlit
 *  and a material would do nothing for it. The texture and
 *  material calls sit together at each draw because both are
 *  shader state that persists until it is changed again: a
 *  shape that set a texture but no material would be lit with
 *  whatever material the previous shape happened to leave
 *  behind.
 ***********************************************************/
void SceneManager::RenderScene()
{
	// render the desk surface the monitor sits on
	RenderDeskSurface();

	// render the complex monitor object - four transformed
	// primitives: base, stand neck, screen panel, display face
	RenderMonitor();

	// render the keyboard sitting in front of the monitor
	RenderKeyboard();

	// render the mouse and the pad it sits on, right of the keyboard
	RenderMousePad();
	RenderMouse();

	// render the two shelf figurines, standing either side of the
	// monitor's base - a mogwai on the left, a Goomba on the right
	RenderGizmoFigurine();
	RenderGoombaFigurine();

	// render the articulated lamp standing beside the keyboard
	RenderDeskLamp();

	// render the Pokeball tumbler to the right of the monitor
	RenderTumbler();

	// draw the camera speed indicator LAST, so the 2D overlay sits
	// on top of the finished 3D scene rather than being drawn into
	// the middle of it
	RenderSpeedIndicator();
}

/***********************************************************
 *  RenderSpeedIndicator()
 *
 *  Implemented by: Matthew Randall
 *
 *  Draws a vertical bar down the left edge of the window that
 *  fills as the camera's movement speed rises and drains as it
 *  falls, giving the scroll wheel visible feedback. Without it
 *  the speed control is invisible: the user turns the wheel and
 *  can only infer what changed by moving and comparing.
 *
 *  A 2D OVERLAY OUT OF 3D PARTS. There is no separate 2D
 *  drawing path in this program and no text rendering, so the
 *  bar and its label are built from the same box mesh as
 *  everything else, drawn through the same shader, in a short pass
 *  that changes three things about how that shader is set up:
 *
 *    1. The PROJECTION becomes an orthographic box spanning
 *       -1 to 1 on both axes, and the VIEW becomes the identity
 *       matrix. Together those put the shader into screen
 *       coordinates: a position is now a fraction of the window
 *       rather than a point in the room, so the bar holds its
 *       place on screen no matter where the camera has moved.
 *    2. LIGHTING is switched off. The bar is a readout, not an
 *       object in the room, and lighting it would let the desk
 *       lamp change the color that carries its meaning.
 *    3. DEPTH TESTING is switched off, so the bar draws over the
 *       scene instead of being hidden by whatever geometry
 *       happens to be nearest the camera.
 *
 *  All three are restored before the method returns. The view
 *  and projection matrices are rewritten by ViewManager at the
 *  start of every frame in any case, but restoring them here
 *  keeps this method's side effects contained rather than
 *  relying on the next frame to clean up after it.
 ***********************************************************/
void SceneManager::RenderSpeedIndicator()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// how far along its adjustable range the camera's speed
	// currently sits, from 0.0 at the slowest to 1.0 at the fastest
	float speedFraction = ViewManager::GetCameraSpeedFraction();

	/*** the bar's geometry, in screen fractions                 ***/
	// x position: in from the left edge of the window, far enough
	// to leave room for the label drawn outside it
	const float barX = -0.86f;
	// the outer track, and the fill that runs inside it. The fill
	// is inset slightly on both axes so the track reads as a
	// border around it rather than as a second bar behind it
	const float trackWidth = 0.050f;
	const float trackHeight = 0.900f;
	const float fillWidth = 0.030f;
	const float fillHeightMax = 0.880f;
	// the overlay is flat, but the box mesh is a solid, so it needs
	// some thickness on Z to exist at all
	const float barDepth = 0.010f;

	/*** switch the shader into 2D overlay mode                  ***/
	// an orthographic volume spanning -1 to 1, with no camera
	// transform applied, so the coordinates above are read as
	// window fractions rather than as positions in the scene
	m_pShaderManager->setMat4Value(g_ViewName, glm::mat4(1.0f));
	m_pShaderManager->setMat4Value(g_ProjectionName,
		glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, -1.0f, 1.0f));
	m_pShaderManager->setBoolValue(g_UseLightingName, false);
	glDisable(GL_DEPTH_TEST);

	/*** the track - the empty channel the fill runs up          ***/
	// dark and partly transparent, so it reads as part of the
	// interface and does not cover the scene behind it outright
	scaleXYZ = glm::vec3(trackWidth, trackHeight, barDepth);
	positionXYZ = glm::vec3(barX, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.06f, 0.06f, 0.08f, 0.55f);
	m_basicMeshes->DrawBoxMesh();

	/*** the fill - the part that rises and falls with the speed ***/
	// skipped entirely at the slowest setting, where its height
	// would be zero and the box would draw as a flat line
	if (speedFraction > 0.005f)
	{
		// the fill grows UPWARD from the bottom of the track. The
		// box mesh is centered on its own origin, so growing it
		// from one end means moving its center up by half of
		// whatever height it has just been given
		float fillHeight = fillHeightMax * speedFraction;
		float fillBottom = -fillHeightMax / 2.0f;

		scaleXYZ = glm::vec3(fillWidth, fillHeight, barDepth);
		positionXYZ = glm::vec3(barX, fillBottom + (fillHeight / 2.0f), 0.0f);
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

		// the fill also changes color as it rises, cool green at
		// the slow end through to warm amber at the fast end. The
		// height already carries the value; the color is what makes
		// the reading legible at a glance, without a number to read
		SetShaderColor(
			0.20f + (0.75f * speedFraction),
			0.80f - (0.35f * speedFraction),
			0.30f - (0.20f * speedFraction),
			0.90f);
		m_basicMeshes->DrawBoxMesh();
	}

	/*** the label - "CAMERA SPEED" running up the outer edge    ***/
	// There is no text rendering anywhere in this program, so the
	// letters are drawn the same way everything else is: as boxes.
	// Each character is a 3 wide by 5 tall grid of pixels, and every
	// lit pixel becomes one small box. Twelve characters at up to
	// twelve lit pixels each is about 120 extra boxes per frame,
	// which is a rounding error next to the keyboard's 106 keycaps
	// and buys a label that needs no font, no image, and no library.
	struct LABEL_GLYPH
	{
		char letter;
		const char* row[5];   // top row first, '#' lit, '.' empty
	};

	const LABEL_GLYPH glyphs[] =
	{
		{ 'C', { "###",
				 "#..",
				 "#..",
				 "#..",
				 "###" } },
		{ 'A', { "###",
				 "#.#",
				 "###",
				 "#.#",
				 "#.#" } },
		{ 'M', { "#.#",
				 "###",
				 "###",
				 "#.#",
				 "#.#" } },
		{ 'E', { "###",
				 "#..",
				 "###",
				 "#..",
				 "###" } },
		{ 'R', { "###",
				 "#.#",
				 "###",
				 "##.",
				 "#.#" } },
		{ 'S', { "###",
				 "#..",
				 "###",
				 "..#",
				 "###" } },
		{ 'P', { "###",
				 "#.#",
				 "###",
				 "#..",
				 "#.." } },
		{ 'D', { "##.",
				 "#.#",
				 "#.#",
				 "#.#",
				 "##." } },
		{ ' ', { "...",
				 "...",
				 "...",
				 "...",
				 "..." } },
	};
	const int glyphCount = sizeof(glyphs) / sizeof(glyphs[0]);

	const char* labelText = "CAMERA SPEED";
	const int labelLength = 12;

	// one pixel of the font, in screen fractions, and the box drawn
	// for it - slightly smaller than its cell so neighboring pixels
	// read as separate squares rather than as a solid block
	const float pixelStep = 0.011f;
	const float pixelSize = pixelStep * 0.85f;
	// 3 columns of letter plus 1 of spacing between characters
	const int characterAdvance = 4;

	// the label is ROTATED a quarter turn so it runs up the edge of
	// the window rather than across it. Rather than rotate the boxes,
	// the two axes are simply swapped as each pixel is placed: a
	// letter's own left-to-right direction becomes screen up, and a
	// letter's own bottom-to-top direction becomes screen left. The
	// text therefore reads upward with the tops of the letters facing
	// the edge of the window, which is how a vertical label along a
	// left hand edge is normally set
	const float labelRightX = barX - (trackWidth / 2.0f) - 0.010f;
	const float labelBottomY =
		-(labelLength * characterAdvance * pixelStep) / 2.0f;

	// a plain light gray - the label names the bar, so it should not
	// compete with the fill color that carries the reading
	SetShaderColor(0.78f, 0.78f, 0.82f, 0.85f);

	for (int i = 0; i < labelLength; i++)
	{
		// find this character's pixel pattern
		const LABEL_GLYPH* glyph = nullptr;
		for (int g = 0; g < glyphCount; g++)
		{
			if (glyphs[g].letter == labelText[i])
			{
				glyph = &glyphs[g];
				break;
			}
		}
		// a character with no pattern defined is skipped rather than
		// drawn as garbage
		if (glyph == nullptr)
		{
			continue;
		}

		for (int r = 0; r < 5; r++)
		{
			for (int c = 0; c < 3; c++)
			{
				if (glyph->row[r][c] != '#')
				{
					continue;
				}

				// position within the letter: across, and up from
				// its baseline (row 0 is the TOP row, so the up
				// distance counts back from the last row)
				float across = (float)c;
				float up = (float)(4 - r);

				scaleXYZ = glm::vec3(pixelSize, pixelSize, barDepth);
				positionXYZ = glm::vec3(
					labelRightX - (up * pixelStep),
					labelBottomY
						+ ((i * characterAdvance + across) * pixelStep),
					0.0f);
				SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
				m_basicMeshes->DrawBoxMesh();
			}
		}
	}

	/*** restore the state this method changed                   ***/
	glEnable(GL_DEPTH_TEST);
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
}

/***********************************************************
 *  RenderDeskSurface()
 *
 *  Implemented by: Matthew Randall
 *
 *  Renders the desk surface as a solid slab rather than a
 *  flat plane, so the desktop has visible edge thickness
 *  when the camera drops below or level with the tabletop.
 *
 *  The box mesh is a unit cube centered on its own origin,
 *  spanning -0.5..0.5 on every axis, so its scale values are
 *  the finished dimensions. The plane mesh this replaced
 *  spanned -1..1 on X and Z, meaning its scale of (10, 1, 6)
 *  produced a 20 x 12 desktop. The X and Z scales below are
 *  therefore doubled to preserve that same footprint.
 *
 *  TEXTURING: the wood grain image is TILED across the slab
 *  rather than stretched. A single copy of the texture spread
 *  over a 20 x 12 desktop would smear the grain into unusable
 *  streaks; repeating it 4 times across and 3 times deep keeps
 *  the grain at a believable real-world scale and keeps the
 *  image sharp instead of pixelated.
 *
 *  LIGHTING: the desktop is the flat surface the rest of the
 *  scene stands on, and it is the surface that shows the
 *  lighting most plainly, because it is large enough for the
 *  gradient the desk lamp lays across it to be visible end to
 *  end. That gradient comes from the ANGLE term rather than from
 *  any distance falloff - the shader has no attenuation, so a
 *  low, close source is the only thing that can produce a pool
 *  of light (see the note in SetupSceneLights). Its "wood"
 *  material gives it a low shininess with a
 *  modest specular, so the reflection it returns is the broad
 *  soft sheen of a satin finished top rather than a mirror
 *  bright spot - a high shininess here would put a hard white
 *  disc on the desktop and flatten the grain the texture work
 *  above was for. Its diffuse value is also held below the
 *  other materials', because the wood image is already a
 *  saturated orange and the desktop faces every light in the
 *  room at once; left as bright as the objects standing on it,
 *  it clipped to a flat blown out orange with no grain left in
 *  it. The warm lamp low on the left, the cool window light
 *  from further left, the fluorescent from behind the camera,
 *  and the monitor's own cool glow spilling forward off the
 *  screen all land on this surface from different angles, so
 *  the slab carries a visible gradient across its width rather
 *  than one flat tone - warm at the lamp end, cooler under the
 *  monitor and out toward the window.
 ***********************************************************/
void SceneManager::RenderDeskSurface()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// thickness of the desktop slab, pulled out as a constant so
	// the Y scale and the Y offset below stay in agreement if the
	// value is ever tuned. The scene runs at roughly 2.6 inches
	// per unit - the 9.0 wide screen panel stands in for a ~24 inch
	// display - so 0.75 units matches the 2 inch top of the real desk
	const float deskThickness = 0.75f;

	// 20 wide x 12 deep, matching the footprint of the plane
	// this replaced, with the slab thickness on the Y axis
	scaleXYZ = glm::vec3(20.0f, deskThickness, 12.0f);

	// the box is centered on its origin, so lowering it by half
	// the thickness leaves the TOP face at Y = 0 -- every object
	// already placed on the desk keeps its position and still
	// rests flush on the surface
	positionXYZ = glm::vec3(0.0f, 0.0f - (deskThickness / 2.0f), 0.0f);

	// apply the scale, rotation (none needed), and position
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// repeat the wood texture 4 times across the width and 3 times
	// across the depth of the slab (see the TEXTURING note above)
	SetTextureUVScale(4.0f, 3.0f);

	// apply the wood grain texture to the desktop
	SetShaderTexture("desk");

	// wood: a wide soft sheen rather than a mirror bright spot,
	// which is what a satin finished desktop does with a light above it
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderMonitor()
 *
 *  Implemented by: Matthew Randall
 *
 *  Renders the computer monitor - the complex object chosen
 *  from my Milestone One reference photo. The monitor is
 *  constructed from FOUR transformed basic 3D shapes:
 *
 *    1. Base         - flattened cylinder (the oval foot)
 *    2. Stand neck   - tapered cylinder, tilted forward so
 *                      its narrow top is buried inside the
 *                      lower part of the screen panel
 *    3. Screen panel - large thin box, tilted back 8 degrees
 *    4. Display face - slightly smaller, thinner box sharing
 *                      the panel's tilt, shifted forward along
 *                      the panel's facing direction so it
 *                      protrudes from the FRONT only and reads
 *                      as a screen inset inside the bezel
 *
 *  Placement math notes (based on the ShapeMeshes primitives):
 *    - The cylinder and tapered cylinder meshes have radius 1
 *      and height 1 with their BASE at the origin, so scale
 *      sets radius (X/Z) and height (Y) directly, and any
 *      rotation pivots around the base, keeping it planted.
 *    - The box mesh is 1 x 1 x 1 CENTERED at the origin, so
 *      box positions are the center point of the box.
 *    - A negative X rotation leans the top of a shape away
 *      from the camera (which sits on the +Z axis); a positive
 *      X rotation leans it toward the camera.
 *
 *  TEXTURING: a different image is applied to each of the four
 *  shapes so every component reads as its real material -
 *  circular brushed stainless on the round base, matte
 *  charcoal on the upright neck and the bezel (sampled at two
 *  different zoom levels so they are not identical), and a
 *  screen capture on the display. Each
 *  texture's UV scale is set immediately before its own draw
 *  call, because the UV scale is shader state that persists
 *  until it is changed again.
 *
 *  LIGHTING: each of the four shapes takes a material chosen
 *  for the real part it stands in for, rather than one
 *  material for the object as a whole. The base is brushed
 *  metal, so it carries the tight bright highlight that reads
 *  as steel; the neck and the bezel are matte plastic with
 *  almost no specular, which is how the black plastic on real
 *  hardware is finished and which keeps the bezel from
 *  competing with the picture inside it. The difference between
 *  the steel base and the matte column directly above it is the
 *  clearest example in the scene of two shapes lit by the same
 *  light returning completely different amounts of it.
 *
 *  THE DISPLAY FACE IS THE EXCEPTION: it is drawn with lighting
 *  switched off and takes no material at all. It is one of the
 *  two light EMITTERS in the scene handled this way - the other
 *  is the desk lamp's bulb, which along with the three glow
 *  shells around it is drawn the same way in RenderDeskLamp()
 *  and for the same reason. The reasoning is at the draw call
 *  below.
 *
 *  Drawing the panel unlit is only half of it, though. A screen
 *  that emits light but puts none into the room is still just a
 *  bright rectangle, so light source [3] in SetupSceneLights()
 *  is positioned just in front of this face, along the same
 *  panelForward normal calculated below. That is what carries
 *  the screen's cool light down onto the keycaps and the desk -
 *  the counterweight to the desk lamp's warm light coming from
 *  the other side of the board.
 ***********************************************************/
void SceneManager::RenderMonitor()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// the backward tilt of the screen, shared by the panel and
	// display face so the two boxes stay perfectly aligned
	const float screenTiltDegrees = -8.0f;

	// the forward tilt of the stand neck. The panel leans BACK,
	// which swings its lower edge FORWARD, so a neck standing
	// perfectly straight stops just short of the panel and ends
	// in mid-air. Leaning the neck forward by this amount drives
	// its top into the lower back of the panel, merging the two
	// shapes into one continuous stand
	const float neckTiltDegrees = 9.0f;

	/******************************************************************/
	/*** MONITOR BASE - flattened cylinder                          ***/
	/*** Scaled wider on X than Z to form the oval foot seen in    ***/
	/*** the reference photo, and squashed on Y to sit low.        ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - X/Z radii 2.6/1.6, height 0.25
	scaleXYZ = glm::vec3(2.6f, 0.25f, 1.6f);

	// set the XYZ rotation for the mesh - the base sits flat on
	// the desk, so no rotation is needed
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh - sunk 0.02 into the desk
	// slab so the base's bottom cap is not coplanar with the
	// desktop, which can z-fight at grazing camera angles. Pushed
	// slightly back on Z so the screen can hang forward over it
	positionXYZ = glm::vec3(0.0f, -0.02f, -0.3f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the base texture is a CIRCULAR brushed pattern, so it is
	// deliberately left untiled - a single copy wraps the disc
	// once and its radial brushing lines up with the round shape.
	// Repeating it would break the pattern into visible arcs
	SetTextureUVScale(1.0f, 1.0f);

	// apply the circular brushed stainless texture
	SetShaderTexture("baseMetal");

	// brushed metal: the strongest specular in the scene, which pulls
	// a bright rim around the curve and reads as steel rather than as
	// gray paint
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** STAND NECK - tapered cylinder, tilted forward              ***/
	/*** Rises from just inside the base and narrows as it climbs, ***/
	/*** with its top embedded in the lower back of the screen     ***/
	/*** panel so the stand and screen read as one assembly.       ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - base radius 0.45, height 3.0.
	// The height overshoots the gap to the panel on purpose so the
	// top of the neck is buried inside it rather than leaving a
	// visible seam, but it is deliberately NOT longer than that:
	// combined with the tilt, this puts the tip roughly halfway
	// through the panel's 0.35 thickness, with clearance both in
	// front and behind. An earlier, longer neck pushed the tip out
	// through the front of the screen
	scaleXYZ = glm::vec3(0.45f, 3.0f, 0.45f);

	// set the XYZ rotation for the mesh - a positive X rotation
	// pivots the neck around its planted base and leans the top
	// forward into the back of the panel (see neckTiltDegrees)
	XrotationDegrees = neckTiltDegrees;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh - centered on the base and
	// starting just below the base's top surface, so no gap shows
	// between the two shapes
	positionXYZ = glm::vec3(0.0f, 0.2f, -0.3f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the neck samples the same backdrop image as the bezel, but
	// zoomed out further (0.15 x 0.30 instead of 0.10 x 0.06).
	// That larger window reaches slightly brighter pixels, so the
	// column lands a shade lighter than the near-black bezel -
	// enough to separate the two parts visually while keeping the
	// whole monitor in one dark color family
	SetTextureUVScale(0.15f, 0.30f);

	// apply the dark matte texture to the stand column. A brushed
	// metal finish was tried here first, but a bright silver
	// column under a black bezel read as mismatched plastic
	// rather than as one piece of hardware
	SetShaderTexture("bezel");

	// matte plastic: almost no specular, the way the black plastic on
	// real hardware is finished so it does not throw glare back
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** SCREEN PANEL - large thin box (the bezel/body)            ***/
	/*** Centered at Y = 5.0 so its bottom edge (5.0 - 2.7 = 2.3)  ***/
	/*** overlaps the top of the neck, attaching the screen to     ***/
	/*** the stand. Tilted back 8 degrees on X like a real monitor.***/
	/******************************************************************/
	// set the XYZ scale for the mesh - 9.0 wide, 5.4 tall, 0.35 deep
	scaleXYZ = glm::vec3(9.0f, 5.4f, 0.35f);

	// set the XYZ rotation for the mesh - negative X rotation leans
	// the top of the screen away from the camera
	XrotationDegrees = screenTiltDegrees;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh - the box is centered at
	// its origin, so this is the center of the screen
	positionXYZ = glm::vec3(0.0f, 5.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// a UV scale BELOW 1 zooms into the texture instead of
	// repeating it. The backdrop image is brightly lit at its
	// center and falls off to near-black in the corner, so
	// sampling only the darkest corner (the first 10 percent
	// across and 6 percent down) fills the bezel with a matte
	// charcoal that matches the real monitor's black plastic.
	// The two values are kept in the same 10:6 ratio as the
	// panel's 9.0 x 5.4 face so the faint mottling in that
	// corner is not stretched out of shape
	SetTextureUVScale(0.10f, 0.06f);

	// apply the dark matte texture to the monitor body/bezel
	SetShaderTexture("bezel");
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/******************************************************************/
	/*** DISPLAY FACE - inset screen box                            ***/
	/*** Smaller than the panel on X and Y, which leaves a visible ***/
	/*** bezel border on all four sides, and only 0.08 deep - just ***/
	/*** thick enough to be a solid shell rather than a flat face. ***/
	/***                                                            ***/
	/*** The box is then nudged FORWARD along the panel's tilted   ***/
	/*** facing direction so that it straddles the panel's front   ***/
	/*** surface: its front face sits slightly proud of the bezel  ***/
	/*** and its back face stays buried inside the panel.          ***/
	/***                                                            ***/
	/*** Keeping this box THIN matters. Earlier versions used a    ***/
	/*** deep box, which left a hollow volume behind the visible   ***/
	/*** screen. Every face of a box mesh receives the texture, so ***/
	/*** flying the camera up to the screen revealed the box's     ***/
	/*** inner side and back faces as extra mirrored copies of the ***/
	/*** wallpaper stacked behind the display. A thin shell leaves ***/
	/*** almost no interior for the camera to see into.            ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - 8.3 x 4.7 face, 0.08 deep
	scaleXYZ = glm::vec3(8.3f, 4.7f, 0.08f);

	// set the XYZ rotation for the mesh - identical tilt to the
	// panel keeps the two boxes perfectly aligned
	XrotationDegrees = screenTiltDegrees;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// calculate the direction the tilted panel faces. Rotating the
	// straight-ahead vector (0, 0, 1) around the X axis by the
	// screen tilt gives the panel's forward normal, so the display
	// can be shifted along the face of the screen rather than
	// straight down the world Z axis. Without this, a tilted screen
	// would push its display out at the wrong angle
	const float tiltRadians = glm::radians(screenTiltDegrees);
	const glm::vec3 panelForward = glm::vec3(
		0.0f,
		-std::sin(tiltRadians),
		std::cos(tiltRadians));

	// how far forward to shift the display from the panel's center.
	// The panel's front face sits 0.175 out from center (half of
	// 0.35) and the display's own front face sits 0.04 out from its
	// center (half of 0.08), so a shift of 0.17 puts the display
	// face 0.035 proud of the bezel - enough to be clearly visible -
	// while its back face stays 0.045 inside the panel
	const float displayOffset = 0.17f;

	// set the XYZ position for the mesh - the panel's center,
	// shifted forward along the direction the screen faces
	positionXYZ = glm::vec3(0.0f, 5.0f, 0.0f)
		+ (panelForward * displayOffset);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the UV scale is deliberately reset to 1 x 1 here. Every other
	// surface in the scene tiles its texture, but a wallpaper shown
	// on a monitor is a single picture - repeating it would destroy
	// the illusion. Resetting is also required rather than optional,
	// because the UV scale set for the bezel above would otherwise
	// carry over into this draw call
	SetTextureUVScale(1.0f, 1.0f);

	// apply the desktop screen capture to the display face
	SetShaderTexture("screen");

	// LIGHTING IS SWITCHED OFF FOR THIS SHAPE. It is one of the two
	// light EMITTERS in the scene drawn this way - the other is the
	// desk lamp's bulb and the glow shells around it, in
	// RenderDeskLamp(). The light this face puts into the rest of
	// the scene is light source [3], positioned just ahead of it
	// along the panelForward normal calculated above.
	//
	// Every other surface here is lit because every other surface
	// REFLECTS the room's light. A powered on display does not: it
	// emits its own light, and what it emits is the image on it.
	// Running it through the lighting model treats the wallpaper as
	// paint on a wall and does two visible kinds of damage. The
	// bright parts of the image are multiplied by the light landing
	// on the panel and clip - the galaxy at the center of this
	// wallpaper blows out to a white smear and takes its detail
	// with it - while the black of space is lifted by the ambient
	// term into a flat gray haze, so the picture loses contrast at
	// both ends at once. On top of that, the panel picks up the
	// color of whichever light it faces, which tints a photograph
	// that has its own colors already.
	//
	// Drawing it unlit hands the texture to the screen exactly as
	// it was captured, which is what a monitor actually shows. It
	// also means the display holds still while the camera moves
	// around the desk, instead of dimming and brightening as the
	// panel turns toward and away from the room lights - a real
	// screen does not get darker when you walk past it
	m_pShaderManager->setBoolValue(g_UseLightingName, false);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	// switch lighting back on immediately. This is shader state
	// like the texture and the UV scale, so leaving it off here
	// would render every object drawn after the monitor unlit as
	// well - which, given RenderScene()'s call order, is all of
	// them but the desk
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
	/****************************************************************/
}

/***********************************************************
 *  RenderKeyboard()
 *
 *  Implemented by: Matthew Randall
 *
 *  Renders the keyboard as its own distinct object, per the
 *  Milestone One feedback that the keyboard and mouse be
 *  modeled separately rather than as one merged shape.
 *
 *  The keyboard in my reference photo is a full size board
 *  with a two tone keycap set: cream caps on the
 *  letters, numbers, and number pad, and black caps on every
 *  modifier and navigation key, all standing in a gray plate
 *  inside a black case.
 *
 *  EVERY KEY IS ITS OWN BOX. An earlier version drew each run
 *  of same colored keys as a single wide block, which got the
 *  colors right but read as a mosaic rather than a keyboard -
 *  the thing the eye actually uses to identify a keyboard is
 *  the grid of small gaps between individual caps, and a
 *  block has none. The 106 boxes this costs are a trivial
 *  amount of geometry for a modern GPU, so the honest version
 *  costs almost nothing and looks enormously better.
 *
 *  THE LAYOUT COMES FROM A TABLE rather than from 106 blocks
 *  of transformation code. Each entry is one cap: which
 *  section it belongs to, which row it sits in, how wide it
 *  is, and what color it takes. A loop walks the table and
 *  places each cap immediately to the right of the one
 *  before it, which means widths - not positions - are all
 *  the table has to get right. Positions fall out of the
 *  accumulation.
 *
 *  KEY UNITS: widths are given in key widths, the unit a real
 *  keyboard is specified in, so a 1.5u Tab, a 2.25u Enter and
 *  a 6.25u space bar are written as 1.5, 2.25 and 6.25 rather
 *  than as scene distances. The three sections each convert
 *  from their own origin and unit width, which holds the main
 *  block, the navigation cluster and the number pad in the
 *  proportions they have on the real board. Every row of the
 *  main block sums to exactly 15 units, which is a useful
 *  check that a row has not been mistyped.
 *
 *  GAPS are entries too. The spaces inside the function row
 *  and above the arrow keys are real parts of the layout, so
 *  they are listed with a width and simply not drawn - the
 *  cursor advances past them.
 ***********************************************************/
void SceneManager::RenderKeyboard()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// the keyboard sits centered on the monitor and forward of
	// it on the Z axis, in the spot it occupies on the real desk
	const glm::vec3 keyboardCenter = glm::vec3(0.0f, 0.0f, 3.0f);

	// height of the case, reused to seat the key plate and caps
	const float caseHeight = 0.42f;

	/******************************************************************/
	/*** CASE - the black body of the keyboard                      ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - 7.5 wide by 2.5 deep, which
	// at roughly 2.3 inches per unit is a ~17 inch full size board
	scaleXYZ = glm::vec3(7.5f, caseHeight, 2.5f);

	// set the XYZ position for the mesh - the box mesh is centered
	// on its origin, so a Y of half the height rests the bottom
	// face flush on the desk at Y = 0
	positionXYZ = glm::vec3(
		keyboardCenter.x,
		caseHeight / 2.0f,
		keyboardCenter.z);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the case samples the darkest corner of the backdrop image at
	// the same zoom used for the monitor bezel, so the keyboard and
	// the monitor read as the same black plastic
	SetTextureUVScale(0.10f, 0.06f);

	// apply the dark matte texture
	SetShaderTexture("bezel");

	// matte plastic: almost no specular, the way the black plastic on
	// real hardware is finished so it does not throw glare back
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/******************************************************************/
	/*** KEY PLATE                                                  ***/
	/***                                                            ***/
	/*** The mounting plate the caps stand in. Every cap is drawn a ***/
	/*** small gap short of its true size on both axes, so this     ***/
	/*** slab is what shows through the grid of gaps between them   ***/
	/*** and around the outside of the key area.                    ***/
	/***                                                            ***/
	/*** It is a MID GRAY, chosen to sit between the two keycap     ***/
	/*** colors: light enough to separate the black caps from the   ***/
	/*** case they sit in, dark enough that the cream caps still    ***/
	/*** stand out against it. An earlier version used the blue of  ***/
	/*** the real board's backlight, but a saturated color across   ***/
	/*** the whole grid pulled the eye straight to the keyboard and ***/
	/*** away from everything else on the desk.                     ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - slightly larger than the key
	// area so a thin border of the plate frames it
	scaleXYZ = glm::vec3(7.20f, 0.06f, 2.32f);

	// set the XYZ position for the mesh - centered on the key area,
	// standing 0.02 above the case so it is not buried in it
	positionXYZ = glm::vec3(keyboardCenter.x, 0.41f, 2.96f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the dark gray of the mounting plate
	SetShaderColor(0.24f, 0.25f, 0.26f, 1.0f);

	// brushed metal: the strongest specular in the scene. The plate is
	// flat rather than curved, so what it returns is a broad sheen
	// across the whole slab rather than the rim the material pulls
	// around the monitor and lamp bases - which is what lifts the
	// exposed gray between the caps and reads as steel, not gray paint
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/******************************************************************/
	/*** KEYCAPS                                                    ***/
	/******************************************************************/
	// which section of the board a cap belongs to
	const int MAIN = 0;
	const int NAV = 1;
	const int PAD = 2;

	// what a cap is made of, or whether it is a hole in the layout
	const int DARK = 0;
	const int CREAM = 1;
	const int GAP = 2;

	// where each section starts across the width of the board, and
	// how wide one key unit is inside it. The main block is 15 units
	// across, the navigation cluster 3, and the number pad 4 - the
	// same proportions as the real board
	const float sectionX[3] = { -3.55f, 1.20f, 2.30f };
	const float sectionUnit[3] = { 4.60f / 15.0f, 0.95f / 3.0f, 1.25f / 4.0f };

	// the front edge of each of the six rows, back to front. The
	// gap between the first two is wider than the rest, which is
	// the break between the function row and the number row
	const float rowFrontZ[6] = { 1.88f, 2.32f, 2.67f, 3.02f, 3.37f, 3.72f };

	// one row is this deep, and the caps stand this tall above the
	// case. The gap is subtracted from every cap on both axes, so
	// the gray plate shows in the grid between them
	const float rowDepth = 0.31f;
	const float capHeight = 0.16f;
	const float capBottom = 0.42f;
	const float keyGap = 0.035f;

	// one keycap, or one hole in the layout
	struct KEY_CAP
	{
		int   section;
		int   row;
		float width;
		int   cap;
	};

	// the layout of the reference keyboard, read left to right and
	// back to front. Caps are listed in the order they appear on
	// the row, because each one is placed against the right hand
	// edge of the one before it
	const KEY_CAP keyCaps[] =
	{
		// ---- function row: Esc, then F1-F12 in three groups ----
		{ MAIN, 0, 1.00f, DARK  },                                  // Esc
		{ MAIN, 0, 1.00f, GAP   },
		{ MAIN, 0, 1.00f, CREAM }, { MAIN, 0, 1.00f, CREAM },       // F1  F2
		{ MAIN, 0, 1.00f, CREAM }, { MAIN, 0, 1.00f, CREAM },       // F3  F4
		{ MAIN, 0, 0.50f, GAP   },
		{ MAIN, 0, 1.00f, DARK  }, { MAIN, 0, 1.00f, DARK  },       // F5  F6
		{ MAIN, 0, 1.00f, DARK  }, { MAIN, 0, 1.00f, DARK  },       // F7  F8
		{ MAIN, 0, 0.50f, GAP   },
		{ MAIN, 0, 1.00f, CREAM }, { MAIN, 0, 1.00f, CREAM },       // F9  F10
		{ MAIN, 0, 1.00f, CREAM }, { MAIN, 0, 1.00f, CREAM },       // F11 F12

		// ---- number row: grave through equals, then backspace ----
		{ MAIN, 1, 1.00f, CREAM },                                  // `
		{ MAIN, 1, 1.00f, CREAM }, { MAIN, 1, 1.00f, CREAM },       // 1 2
		{ MAIN, 1, 1.00f, CREAM }, { MAIN, 1, 1.00f, CREAM },       // 3 4
		{ MAIN, 1, 1.00f, CREAM }, { MAIN, 1, 1.00f, CREAM },       // 5 6
		{ MAIN, 1, 1.00f, CREAM }, { MAIN, 1, 1.00f, CREAM },       // 7 8
		{ MAIN, 1, 1.00f, CREAM }, { MAIN, 1, 1.00f, CREAM },       // 9 0
		{ MAIN, 1, 1.00f, CREAM }, { MAIN, 1, 1.00f, CREAM },       // - =
		{ MAIN, 1, 2.00f, DARK  },                                  // Backspace

		// ---- QWERTY row: tab, then letters out to the backslash ----
		{ MAIN, 2, 1.50f, DARK  },                                  // Tab
		{ MAIN, 2, 1.00f, CREAM }, { MAIN, 2, 1.00f, CREAM },       // Q W
		{ MAIN, 2, 1.00f, CREAM }, { MAIN, 2, 1.00f, CREAM },       // E R
		{ MAIN, 2, 1.00f, CREAM }, { MAIN, 2, 1.00f, CREAM },       // T Y
		{ MAIN, 2, 1.00f, CREAM }, { MAIN, 2, 1.00f, CREAM },       // U I
		{ MAIN, 2, 1.00f, CREAM }, { MAIN, 2, 1.00f, CREAM },       // O P
		{ MAIN, 2, 1.00f, CREAM }, { MAIN, 2, 1.00f, CREAM },       // [ ]
		{ MAIN, 2, 1.50f, CREAM },                                  // backslash

		// ---- home row: caps lock, letters, enter ----
		{ MAIN, 3, 1.75f, DARK  },                                  // Caps Lock
		{ MAIN, 3, 1.00f, CREAM }, { MAIN, 3, 1.00f, CREAM },       // A S
		{ MAIN, 3, 1.00f, CREAM }, { MAIN, 3, 1.00f, CREAM },       // D F
		{ MAIN, 3, 1.00f, CREAM }, { MAIN, 3, 1.00f, CREAM },       // G H
		{ MAIN, 3, 1.00f, CREAM }, { MAIN, 3, 1.00f, CREAM },       // J K
		{ MAIN, 3, 1.00f, CREAM }, { MAIN, 3, 1.00f, CREAM },       // L ;
		{ MAIN, 3, 1.00f, CREAM },                                  // '
		{ MAIN, 3, 2.25f, DARK  },                                  // Enter

		// ---- bottom letter row: shift, letters, shift ----
		{ MAIN, 4, 2.25f, DARK  },                                  // Left Shift
		{ MAIN, 4, 1.00f, CREAM }, { MAIN, 4, 1.00f, CREAM },       // Z X
		{ MAIN, 4, 1.00f, CREAM }, { MAIN, 4, 1.00f, CREAM },       // C V
		{ MAIN, 4, 1.00f, CREAM }, { MAIN, 4, 1.00f, CREAM },       // B N
		{ MAIN, 4, 1.00f, CREAM },                                  // M
		{ MAIN, 4, 1.00f, CREAM }, { MAIN, 4, 1.00f, CREAM },       // , .
		{ MAIN, 4, 1.00f, CREAM },                                  // /
		{ MAIN, 4, 2.75f, DARK  },                                  // Right Shift

		// ---- modifier row: the cream space bar among black keys ----
		{ MAIN, 5, 1.25f, DARK  }, { MAIN, 5, 1.25f, DARK  },       // Ctrl Win
		{ MAIN, 5, 1.25f, DARK  },                                  // Alt
		{ MAIN, 5, 6.25f, CREAM },                                  // Space
		{ MAIN, 5, 1.25f, DARK  }, { MAIN, 5, 1.25f, DARK  },       // Alt Fn
		{ MAIN, 5, 1.25f, DARK  }, { MAIN, 5, 1.25f, DARK  },       // Menu Ctrl

		// ---- navigation cluster: all black ----
		{ NAV,  0, 1.00f, DARK  }, { NAV,  0, 1.00f, DARK  },       // PrtSc ScrLk
		{ NAV,  0, 1.00f, DARK  },                                  // Pause
		{ NAV,  1, 1.00f, DARK  }, { NAV,  1, 1.00f, DARK  },       // Ins Home
		{ NAV,  1, 1.00f, DARK  },                                  // PgUp
		{ NAV,  2, 1.00f, DARK  }, { NAV,  2, 1.00f, DARK  },       // Del End
		{ NAV,  2, 1.00f, DARK  },                                  // PgDn
		// row 3 is left empty - the blank space above the arrows
		{ NAV,  4, 1.00f, GAP   },
		{ NAV,  4, 1.00f, DARK  },                                  // Up
		{ NAV,  5, 1.00f, DARK  }, { NAV,  5, 1.00f, DARK  },       // Left Down
		{ NAV,  5, 1.00f, DARK  },                                  // Right

		// ---- number pad: black top row, cream digits below ----
		{ PAD,  1, 1.00f, DARK  }, { PAD,  1, 1.00f, DARK  },       // Num /
		{ PAD,  1, 1.00f, DARK  }, { PAD,  1, 1.00f, DARK  },       // * -
		{ PAD,  2, 1.00f, CREAM }, { PAD,  2, 1.00f, CREAM },       // 7 8
		{ PAD,  2, 1.00f, CREAM }, { PAD,  2, 1.00f, CREAM },       // 9 +
		{ PAD,  3, 1.00f, CREAM }, { PAD,  3, 1.00f, CREAM },       // 4 5
		{ PAD,  3, 1.00f, CREAM }, { PAD,  3, 1.00f, CREAM },       // 6 +
		{ PAD,  4, 1.00f, CREAM }, { PAD,  4, 1.00f, CREAM },       // 1 2
		{ PAD,  4, 1.00f, CREAM }, { PAD,  4, 1.00f, CREAM },       // 3 Enter
		{ PAD,  5, 2.00f, CREAM },                                  // 0
		{ PAD,  5, 1.00f, CREAM }, { PAD,  5, 1.00f, CREAM }        // . Enter
	};

	// the left hand edge of the cap being placed, and which row it
	// was last reset for. Every cap is laid against the right hand
	// edge of the one before it, so the cursor only has to be sent
	// back to a section's origin when the row changes
	float cursorX = 0.0f;
	int placedSection = -1;
	int placedRow = -1;

	for (const KEY_CAP& key : keyCaps)
	{
		// starting a new row - send the cursor back to the left hand
		// edge of whichever section this row belongs to
		if (key.section != placedSection || key.row != placedRow)
		{
			placedSection = key.section;
			placedRow = key.row;
			cursorX = sectionX[key.section];
		}

		// the cap's width in scene units, converted from key units
		// by its own section's unit width
		const float capWidth = key.width * sectionUnit[key.section];

		// gaps in the layout are advanced past without drawing
		if (key.cap != GAP)
		{
			// set the XYZ scale for the mesh - the cap's own width
			// and one row's depth, each less the gap that lets the
			// plate show through between neighbors
			scaleXYZ = glm::vec3(
				capWidth - keyGap,
				capHeight,
				rowDepth - keyGap);

			// set the XYZ position for the mesh - the box mesh is
			// centered on its origin, so the cap sits half its own
			// width right of the cursor and half a row deep into
			// its row, standing on the case
			positionXYZ = glm::vec3(
				cursorX + (capWidth / 2.0f),
				capBottom + (capHeight / 2.0f),
				rowFrontZ[key.row] + (rowDepth / 2.0f));

			// set the transformations into memory to be used on the drawn meshes
			SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

			// the two keycap colors from the reference photo.
			// Neither is pushed to a pure value - the cream is a
			// warm off white and the black is a lifted near black,
			// which leaves both room to take a specular highlight
			// without the cream clipping to white
			if (key.cap == CREAM)
			{
				SetShaderColor(0.87f, 0.84f, 0.75f, 1.0f);
			}
			else
			{
				SetShaderColor(0.12f, 0.12f, 0.13f, 1.0f);
			}

			// keycap plastic: enough highlight to catch the top edge of every
			// cap, which is what separates one cap from the next across a field
			// of over a hundred boxes of the same color
			SetShaderMaterial("keycap");

			// draw the mesh with transformation values
			m_basicMeshes->DrawBoxMesh();
		}

		// move the cursor past this cap, drawn or not, so the next
		// one lands against its right hand edge
		cursorX += capWidth;
	}
	/****************************************************************/
}

/***********************************************************
 *  RenderMousePad()
 *
 *  Implemented by: Matthew Randall
 *
 *  Renders the cloth mouse pad the mouse sits on, built from
 *  TWO transformed boxes: a dark slab for the stitched border
 *  and a slightly smaller, slightly taller one inset into it
 *  for the printed surface.
 *
 *  Two boxes rather than one because the stitched edge is the
 *  detail that makes a cloth pad read as a cloth pad instead
 *  of as a rectangle of paint on the desk. Leaving a narrow
 *  margin of the darker slab showing all the way around gives
 *  that border for the cost of one extra primitive.
 *
 *  The pad is only a few hundredths of a unit thick, which is
 *  what a real one is - thin enough that the mouse sitting on
 *  it still looks like it is on the desk.
 ***********************************************************/
void SceneManager::RenderMousePad()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// the pad is centered under the mouse, shifted right of where
	// the mouse used to sit so there is room for a realistic one.
	//
	// SIZING: a real gaming pad is about 13.8 x 9.8 inches, which
	// at this scene's ~2.3 inches per unit would be 6.0 x 4.3 - too
	// wide to fit between the keyboard's right edge at X = 3.75 and
	// the edge of the desk. 4.2 x 3.4 is a medium pad at 9.7 x 7.8
	// inches, which is as large as the desk allows and still reads
	// as a pad the mouse has room to move on. An earlier version at
	// 2.8 across was barely wider than the mouse itself and made
	// the mouse look oversized
	const float padX = 6.05f;
	const float padZ = 3.0f;
	const float padThickness = 0.05f;

	/******************************************************************/
	/*** BORDER - the darker slab underneath                        ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - the full footprint of the pad
	scaleXYZ = glm::vec3(4.20f, padThickness, 3.40f);

	// set the XYZ position for the mesh - the box mesh is centered
	// on its origin, so half the thickness leaves the bottom face
	// resting flush on the desk at Y = 0
	positionXYZ = glm::vec3(padX, padThickness / 2.0f, padZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// a dark navy for the stitched edge
	SetShaderColor(0.09f, 0.11f, 0.20f, 1.0f);

	// cloth: the only material in the scene with its specular at
	// effectively zero. The pad and the desk are both flat surfaces
	// under the same overhead light, so this difference in finish is
	// the only thing that tells them apart
	SetShaderMaterial("cloth");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/******************************************************************/
	/*** SURFACE - the printed cloth inset into the border          ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - 0.12 narrower and shallower
	// than the border, which leaves a 0.06 edge showing all round
	scaleXYZ = glm::vec3(4.08f, padThickness, 3.28f);

	// set the XYZ position for the mesh - raised 0.01 above the
	// border, so the two are not coplanar and cannot z-fight
	positionXYZ = glm::vec3(padX, (padThickness / 2.0f) + 0.01f, padZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the blue of the printed surface
	SetShaderColor(0.16f, 0.24f, 0.46f, 1.0f);
	SetShaderMaterial("cloth");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/
}

/***********************************************************
 *  RenderMouse()
 *
 *  Implemented by: Matthew Randall
 *
 *  Renders the mouse as its own distinct object, per the
 *  Milestone One feedback that the keyboard and mouse be
 *  modeled separately rather than as one merged shape. It is
 *  built from ELEVEN transformed primitives:
 *
 *    1. Palm hump    - a short broad sphere at the rear
 *    2. Front body   - a longer, lower sphere at the nose
 *    3, 4. Buttons   - two tilted boxes either side of the
 *                      wheel channel
 *    5. Scroll wheel - a cylinder laid on its side
 *    6, 7. DPI pads  - two small gray boxes behind the wheel
 *    8. Thumb flare  - a sphere stretched along the left side
 *    9. Side button  - a small gray box on the flare
 *    10. Base skirt  - a flat gray sphere ringing the foot
 *    11. Logo plate  - a small gray oval on the hump
 *
 *  WHAT MAKES IT READ AS A MOUSE, working from the reference
 *  photos of the actual Redragon on my desk:
 *
 *    - the TAPER. The body is not a symmetrical blob. It is
 *      tall and broad at the back where the palm rests and
 *      drops away lower and narrower toward the front, so it
 *      is built from TWO spheres of different sizes rather
 *      than from one. An earlier version used a single
 *      squashed sphere and read as a stone
 *    - the SPLIT between the two main buttons, with the
 *      scroll wheel sitting down in the channel between them.
 *      That gap along the front half is the single most
 *      identifiable feature of a mouse
 *    - the THUMB FLARE on the left side, with a side button
 *      on it
 *
 *  ORIENTATION: the front of the mouse - buttons, wheel, and
 *  where the cable would leave - points AWAY from the user,
 *  toward -Z, with the palm hump nearest the camera. An
 *  earlier version had this reversed and put the wheel under
 *  the heel of the hand.
 *
 *  SPHERE PLACEMENT: the sphere mesh is centered on its own
 *  origin, so the body spheres are positioned at the height
 *  of the pad surface and their lower halves pass down through
 *  the pad and into the desk slab. Both are solid, so the
 *  buried halves are enclosed and never visible from any
 *  camera angle - and what remains above is the flat bottomed
 *  dome a mouse has.
 *
 *  COLOR: flat shader colors, not textures. The mouse was
 *  previously given the same dark image as the monitor bezel,
 *  which at this scale sampled to a mottled brown and made the
 *  whole object look like a lump of wood.
 *
 *  Flat black alone is not enough either - an all black mouse
 *  loses every internal edge and reads as a rock. The shell is
 *  therefore drawn in THREE values: near black for the body, a
 *  step lighter for the buttons so their seams show, and a
 *  much lighter gray for the trim - the skirt around the foot,
 *  the logo plate, the DPI pads and the thumb switch. Those
 *  gray accents are on the real mouse, and they are what give
 *  the silhouette its internal structure.
 ***********************************************************/
void SceneManager::RenderMouse()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// the mouse sits to the right of the keyboard, centered on its
	// pad, where it rests on the real desk
	const float mouseX = 6.05f;
	const float mouseZ = 3.0f;

	// the height of the pad surface the mouse stands on, so the body
	// is seated on the cloth rather than sunk to the bare desk
	const float padTop = 0.05f;

	// the three plastics. A mouse rendered in one flat black reads
	// as a rock, so the black is broken up on purpose: the buttons
	// sit a step off the shell so their seams show, and a much
	// lighter gray picks out the trim - the skirt around the base,
	// the logo plate, the DPI pads and the thumb switch. The real
	// mouse has exactly these gray accents, and they are what stop
	// the silhouette reading as one solid lump
	const glm::vec3 shellBlack = glm::vec3(0.12f, 0.12f, 0.13f);
	const glm::vec3 buttonBlack = glm::vec3(0.23f, 0.23f, 0.25f);
	const glm::vec3 trimGray = glm::vec3(0.47f, 0.48f, 0.51f);

	/******************************************************************/
	/*** PALM HUMP - the tall broad rear of the shell               ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - the widest and tallest part
	// of the mouse, about 2.7 inches across in scene scale. It is
	// deliberately SHORT front to back: an earlier version made the
	// hump nearly as long as it was wide, which swallowed the nose
	// and left the whole mouse reading as one ball
	scaleXYZ = glm::vec3(0.58f, 0.70f, 0.62f);

	// set the XYZ position for the mesh - centered ON the pad
	// surface so only the upper half of the sphere shows, and set
	// well back toward the user (see SPHERE PLACEMENT above)
	positionXYZ = glm::vec3(mouseX, padTop, mouseZ + 0.42f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// matte black plastic
	SetShaderColor(shellBlack.x, shellBlack.y, shellBlack.z, 1.0f);

	// glossy plastic: a tight highlight, which is what makes a curved
	// shape drawn in one flat color read as solid rather than as a
	// silhouette
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** FRONT BODY - the lower narrower nose of the shell          ***/
	/*** Smaller than the hump on every axis and overlapping it,    ***/
	/*** which is what produces the taper from a broad palm rest    ***/
	/*** down to a low nose instead of a symmetrical mound.         ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - narrower and noticeably lower
	// than the hump, and LONGER than it, so most of the mouse's
	// length lives in the low front half where a real one does
	scaleXYZ = glm::vec3(0.48f, 0.50f, 0.85f);

	// set the XYZ position for the mesh - forward of the hump, and
	// overlapping it so the two blend into one shell
	positionXYZ = glm::vec3(mouseX, padTop, mouseZ - 0.35f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the same matte black
	SetShaderColor(shellBlack.x, shellBlack.y, shellBlack.z, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** MAIN BUTTONS - two panels either side of the wheel channel ***/
	/***                                                            ***/
	/*** Each is tilted nose DOWN to follow the shell falling away  ***/
	/*** toward the front. A NEGATIVE X rotation lowers the -Z end  ***/
	/*** of a box and lifts the +Z end, which is the way round this ***/
	/*** needs, since the front of the mouse points at -Z.          ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - long, narrow, and thin
	scaleXYZ = glm::vec3(0.22f, 0.08f, 0.60f);

	// set the XYZ rotation for the mesh - the nose down tilt that
	// matches the slope of the shell beneath
	XrotationDegrees = -13.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh - the LEFT button, set off
	// the center line to leave the wheel channel between the pair
	positionXYZ = glm::vec3(mouseX - 0.15f, 0.53f, mouseZ - 0.55f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the lighter button plastic
	SetShaderColor(buttonBlack.x, buttonBlack.y, buttonBlack.z, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	// set the XYZ position for the mesh - the RIGHT button, mirrored
	// across the channel
	positionXYZ = glm::vec3(mouseX + 0.15f, 0.53f, mouseZ - 0.55f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the same button plastic
	SetShaderColor(buttonBlack.x, buttonBlack.y, buttonBlack.z, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	// clear the tilt so it does not carry into the shapes below
	XrotationDegrees = 0.0f;
	/****************************************************************/

	/******************************************************************/
	/*** SCROLL WHEEL - a cylinder laid on its side in the channel  ***/
	/***                                                            ***/
	/*** The cylinder mesh stands upright with its BASE at the      ***/
	/*** origin and its axis running up +Y. A Z rotation of 90      ***/
	/*** swings that axis onto -X, so the wheel spins ACROSS the    ***/
	/*** mouse rather than along it. Because the rotation pivots    ***/
	/*** around the base, the cylinder grows in -X from wherever it ***/
	/*** is positioned, so the X position below is offset by half   ***/
	/*** its length to leave it centered in the channel.            ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - radius 0.10, and just narrow
	// enough to sit in the gap between the two buttons
	scaleXYZ = glm::vec3(0.10f, 0.14f, 0.10f);

	// set the XYZ rotation for the mesh - lay the cylinder over so
	// its flat circular faces look left and right
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh - down in the channel, at a
	// height that leaves only the top arc of the wheel standing
	// above the buttons either side of it
	positionXYZ = glm::vec3(mouseX + 0.07f, 0.52f, mouseZ - 0.42f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// a lighter gray than either plastic, which is what makes the
	// rubber tire of the wheel stand out down inside the channel
	SetShaderColor(0.36f, 0.36f, 0.38f, 1.0f);

	// rubber: the dullest surface on an otherwise glossy shell, which
	// is what makes the wheel visible down inside its channel
	SetShaderMaterial("rubber");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	// clear the rotation so it does not carry into the shapes below
	ZrotationDegrees = 0.0f;
	/****************************************************************/

	/******************************************************************/
	/*** DPI BUTTONS - two small pads on the spine behind the wheel ***/
	/*** Set on the center line where the shell climbs toward the   ***/
	/*** hump, each a little higher than the one in front of it so  ***/
	/*** both sit on the slope rather than floating over it.        ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - small square pads
	scaleXYZ = glm::vec3(0.11f, 0.06f, 0.10f);

	// set the XYZ position for the mesh - the forward pad
	positionXYZ = glm::vec3(mouseX, 0.57f, mouseZ - 0.20f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// gray, not black - these are two of the small trim details
	// that break up the shell
	SetShaderColor(trimGray.x, trimGray.y, trimGray.z, 1.0f);

	// brushed metal: these pads are flat boxes, so the strong specular
	// gives them a hard bright top face against the curved shell they
	// sit on, which is exactly what separates a trim detail from the
	// body it is set into
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	// set the XYZ position for the mesh - the rear pad, just behind
	// the first on the same stretch of spine
	positionXYZ = glm::vec3(mouseX, 0.55f, mouseZ - 0.06f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the same trim gray
	SetShaderColor(trimGray.x, trimGray.y, trimGray.z, 1.0f);
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/******************************************************************/
	/*** THUMB FLARE - the shelf along the left side                ***/
	/*** Long on Z and thin on X, so it reads as a ledge running    ***/
	/*** down the side of the shell rather than as a lump stuck to  ***/
	/*** it. The camera sits left of the mouse, so this side is the ***/
	/*** one actually in view.                                      ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - a low narrow ledge
	scaleXYZ = glm::vec3(0.18f, 0.20f, 0.48f);

	// set the XYZ position for the mesh - out past the left flank of
	// the shell, low down where a thumb would rest
	positionXYZ = glm::vec3(mouseX - 0.56f, 0.22f, mouseZ + 0.05f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the shell black
	SetShaderColor(shellBlack.x, shellBlack.y, shellBlack.z, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** SIDE BUTTON - the thumb switch on the flare                ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - a small bar, long on Z
	scaleXYZ = glm::vec3(0.06f, 0.07f, 0.22f);

	// set the XYZ position for the mesh - standing proud of the
	// outer face of the flare, low enough down it that the flare is
	// still near its full width there and the button is not left
	// floating off a surface that has already curved away
	positionXYZ = glm::vec3(mouseX - 0.75f, 0.28f, mouseZ - 0.04f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the trim gray, so the switch reads against the black flare
	SetShaderColor(trimGray.x, trimGray.y, trimGray.z, 1.0f);
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/******************************************************************/
	/*** BASE SKIRT - the gray band around the bottom of the shell  ***/
	/***                                                            ***/
	/*** A wide flat sphere set at the height of the pad, scaled a  ***/
	/*** little larger across than the shell above it, so what      ***/
	/*** shows is a thin gray rim running the whole way around the  ***/
	/*** foot of the mouse. Real mice have exactly this band where  ***/
	/*** the top shell meets the base, and it does more than any    ***/
	/*** other single shape here to stop the object reading as a    ***/
	/*** solid black lump.                                          ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - 0.05 wider across than the
	// shell, and flattened hard on Y so it is a band and not a bulge
	scaleXYZ = glm::vec3(0.63f, 0.07f, 1.16f);

	// set the XYZ position for the mesh - at the midpoint of the
	// shell's own length rather than at the mouse's center, since
	// the nose reaches further forward than the hump reaches back
	positionXYZ = glm::vec3(mouseX, 0.09f, mouseZ - 0.08f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the trim gray
	SetShaderColor(trimGray.x, trimGray.y, trimGray.z, 1.0f);
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** LOGO PLATE - the gray oval on the back of the palm hump    ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - a small flat oval
	scaleXYZ = glm::vec3(0.15f, 0.05f, 0.18f);

	// set the XYZ position for the mesh - on the upper rear slope of
	// the hump, where the maker's badge sits on the real mouse
	positionXYZ = glm::vec3(mouseX, 0.71f, mouseZ + 0.55f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the trim gray
	SetShaderColor(trimGray.x, trimGray.y, trimGray.z, 1.0f);
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/
}

/***********************************************************
 *  RenderGizmoFigurine()
 *
 *  Implemented by: Matthew Randall
 *
 *  Renders the first of the two shelf figurines, a Gizmo
 *  (the mogwai from Gremlins), built from SEVENTEEN
 *  transformed primitives on its display base.
 *
 *  Per the Milestone One feedback each figurine is its own
 *  distinct object with its own render method, and the two
 *  are given deliberately different silhouettes so they do
 *  not read as one shape drawn twice.
 *
 *  WHAT MAKES IT READ AS GIZMO, working from the reference
 *  photo of the actual figure on my shelf:
 *
 *    - the TWO TONE fur. Brown over the back and the crown of
 *      the head, white down the front and on the hands and
 *      feet, with a white mask around the eyes. A single
 *      colored body loses the character completely, so the
 *      body and head are each built as a brown shape with a
 *      white shape set into the front of it
 *    - the EARS, which are longer than the head is wide and
 *      angled up and out rather than straight sideways
 *    - the EYES, which are large, set wide, and dark against
 *      the white mask
 *
 *  Fur texture, fingers, and markings would not be visible at
 *  this scale, so none of them are modeled. The color split
 *  and the proportions carry the likeness.
 *
 *  COLOR: drawn with flat shader colors rather than textures.
 *  Every texture loaded for this scene is a hard surface
 *  material - wood, brushed steel, matte black plastic - and
 *  none of them suits fur or painted resin, so a solid color
 *  is the more honest choice than stretching an unrelated
 *  image over the shapes.
 ***********************************************************/
void SceneManager::RenderGizmoFigurine()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// where the figurine stands - just left of the monitor's oval
	// base, which reaches out to X = -2.6. Standing the figurines
	// either side of the base groups them with the monitor instead
	// of leaving them stranded at the edge of the desk.
	//
	// This sits BEHIND the screen panel's plane, which is only safe
	// because the figurine is short: the panel's bottom edge is at
	// Y = 2.3 and nothing here reaches half that, so the line of
	// sight from the default camera passes UNDER the screen rather
	// than into it
	const float gizmoX = -3.5f;
	const float gizmoZ = -0.2f;

	// the palette, named because most of these are used more than
	// once and the two tone split is the whole likeness
	const glm::vec3 furBrown = glm::vec3(0.50f, 0.38f, 0.29f);
	const glm::vec3 furWhite = glm::vec3(0.93f, 0.92f, 0.90f);
	const glm::vec3 skinTan = glm::vec3(0.85f, 0.66f, 0.53f);
	const glm::vec3 eyeWhite = glm::vec3(0.95f, 0.94f, 0.92f);
	const glm::vec3 eyeDark = glm::vec3(0.26f, 0.14f, 0.08f);

	/******************************************************************/
	/*** DISPLAY BASE - the disc the figure is mounted on           ***/
	/*** The real figure stands on a weighted display base, and     ***/
	/*** including it means the feet meet a flat surface instead of ***/
	/*** disappearing into the desk.                                ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - radius 0.42, very shallow
	scaleXYZ = glm::vec3(0.42f, 0.06f, 0.42f);

	// set the XYZ position for the mesh - the cylinder mesh has its
	// base at the origin, so Y = 0 rests it on the desk surface
	positionXYZ = glm::vec3(gizmoX, 0.0f, gizmoZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// a dark charcoal for the base
	SetShaderColor(0.20f, 0.20f, 0.22f, 1.0f);

	// matte plastic: almost no specular, the way the black plastic on
	// real hardware is finished so it does not throw glare back
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** FEET - two white spheres, stretched forward                ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - low and longer than wide, so
	// they read as feet rather than as balls
	scaleXYZ = glm::vec3(0.12f, 0.07f, 0.16f);

	// set the XYZ position for the mesh - the right foot, set
	// forward of the body so the toes lead
	positionXYZ = glm::vec3(gizmoX + 0.14f, 0.11f, gizmoZ + 0.13f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// white fur
	SetShaderColor(furWhite.x, furWhite.y, furWhite.z, 1.0f);

	// painted resin: a soft sheen spread wide across the surface, the
	// way a clear coated figure carries it, so shapes this small keep
	// their curve instead of flattening out
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ position for the mesh - the left foot
	positionXYZ = glm::vec3(gizmoX - 0.14f, 0.11f, gizmoZ + 0.13f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// white fur
	SetShaderColor(furWhite.x, furWhite.y, furWhite.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** BODY - a brown back with a white front set into it         ***/
	/***                                                            ***/
	/*** This is the two tone trick that the whole figure depends   ***/
	/*** on. The brown sphere is pushed BACK on Z and the white one ***/
	/*** FORWARD, so from the front the white belly covers the       ***/
	/*** brown almost completely, and from any other angle the      ***/
	/*** brown back shows behind it. Two overlapping spheres cost   ***/
	/*** far less than trying to texture a color split onto one.    ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - the brown back, slightly
	// narrower than the belly and shallower on Z
	scaleXYZ = glm::vec3(0.31f, 0.35f, 0.25f);

	// set the XYZ position for the mesh - set back and a little high,
	// which is where a mogwai's shoulders sit
	positionXYZ = glm::vec3(gizmoX, 0.54f, gizmoZ - 0.09f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// brown fur
	SetShaderColor(furBrown.x, furBrown.y, furBrown.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ scale for the mesh - the white belly, the widest
	// part of the body
	scaleXYZ = glm::vec3(0.32f, 0.36f, 0.28f);

	// set the XYZ position for the mesh - set forward of the back
	positionXYZ = glm::vec3(gizmoX, 0.48f, gizmoZ + 0.04f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// white fur
	SetShaderColor(furWhite.x, furWhite.y, furWhite.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** HEAD - brown, with a white mask and crown tuft             ***/
	/*** Wider than the body and nearly as tall. The oversized head ***/
	/*** is the point: a mogwai is mostly head, and matching it to  ***/
	/*** the body would turn the figurine into a generic snowman.   ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - wider on X than the body is
	scaleXYZ = glm::vec3(0.36f, 0.32f, 0.32f);

	// set the XYZ position for the mesh - a center of 1.06 puts the
	// bottom of the head at 0.74, sinking it into the body's 0.84
	// top so no seam shows between them
	positionXYZ = glm::vec3(gizmoX, 1.06f, gizmoZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// brown fur
	SetShaderColor(furBrown.x, furBrown.y, furBrown.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ scale for the mesh - the white face mask, flattened
	// hard on Z so it lies against the face instead of bulging off it
	scaleXYZ = glm::vec3(0.26f, 0.23f, 0.13f);

	// set the XYZ position for the mesh - forward on the head, and
	// slightly low, which is where the eyes and muzzle sit
	positionXYZ = glm::vec3(gizmoX, 1.02f, gizmoZ + 0.22f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// white fur
	SetShaderColor(furWhite.x, furWhite.y, furWhite.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ scale for the mesh - the white tuft on the crown,
	// wide and flat like a patch of fur rather than a lump
	scaleXYZ = glm::vec3(0.16f, 0.09f, 0.13f);

	// set the XYZ position for the mesh - sitting on top of the head
	positionXYZ = glm::vec3(gizmoX, 1.32f, gizmoZ + 0.05f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// white fur
	SetShaderColor(furWhite.x, furWhite.y, furWhite.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** EARS - two cones angled up and out                         ***/
	/***                                                            ***/
	/*** The cone mesh stands with its wide base at the origin and  ***/
	/*** its point straight up. A Z rotation of -90 would swing     ***/
	/*** that point onto +X and lay the ear flat; using -75 instead ***/
	/*** leaves it 15 degrees ABOVE horizontal, which is the angle  ***/
	/*** the ears sit at on the real figure. The mirrored +75 does  ***/
	/*** the same on the other side from the same loaded mesh.      ***/
	/***                                                            ***/
	/*** The scale is applied BEFORE the rotation, so the 0.15 base ***/
	/*** radius becomes the ear's thickness and the 0.50 height     ***/
	/*** becomes its reach - longer than the head is wide, which is ***/
	/*** what makes them read as mogwai ears and not cat ears.      ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - reaching 0.50 out from the
	// head, and flattened on Z so the ear is a broad blade
	scaleXYZ = glm::vec3(0.15f, 0.50f, 0.08f);

	// set the XYZ rotation for the mesh - the RIGHT ear, out and up
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -75.0f;

	// set the XYZ position for the mesh - started inside the head so
	// the wide base of the cone is hidden and only the tapering
	// blade of the ear shows
	positionXYZ = glm::vec3(gizmoX + 0.19f, 1.10f, gizmoZ - 0.02f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the pinkish tan of the ears
	SetShaderColor(skinTan.x, skinTan.y, skinTan.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();

	// set the XYZ rotation for the mesh - the mirrored LEFT ear
	ZrotationDegrees = 75.0f;

	// set the XYZ position for the mesh - mirrored across the head
	positionXYZ = glm::vec3(gizmoX - 0.19f, 1.10f, gizmoZ - 0.02f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the same pinkish tan
	SetShaderColor(skinTan.x, skinTan.y, skinTan.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();

	// clear the rotation so it does not carry into the shapes below
	ZrotationDegrees = 0.0f;
	/****************************************************************/

	/******************************************************************/
	/*** EYES - a pale sphere with a dark one set in front of it    ***/
	/*** Two shapes per eye rather than one flat dark dot, because  ***/
	/*** the ring of white around the iris is what gives the figure ***/
	/*** its wide eyed look.                                        ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - the eye, flattened on Z so it
	// follows the face
	scaleXYZ = glm::vec3(0.10f, 0.11f, 0.06f);

	// set the XYZ position for the mesh - the right eye, set wide on
	// the white mask
	positionXYZ = glm::vec3(gizmoX + 0.13f, 1.04f, gizmoZ + 0.30f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the pale of the eye
	SetShaderColor(eyeWhite.x, eyeWhite.y, eyeWhite.z, 1.0f);

	// glossy plastic: a tight highlight, which is what makes a curved
	// shape drawn in one flat color read as solid rather than as a
	// silhouette
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ position for the mesh - the left eye
	positionXYZ = glm::vec3(gizmoX - 0.13f, 1.04f, gizmoZ + 0.30f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the same pale
	SetShaderColor(eyeWhite.x, eyeWhite.y, eyeWhite.z, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ scale for the mesh - the iris, a little over half
	// the eye, which leaves the pale showing all around it
	scaleXYZ = glm::vec3(0.065f, 0.075f, 0.045f);

	// set the XYZ position for the mesh - in front of the right eye
	positionXYZ = glm::vec3(gizmoX + 0.13f, 1.03f, gizmoZ + 0.34f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the dark brown of the iris
	SetShaderColor(eyeDark.x, eyeDark.y, eyeDark.z, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ position for the mesh - in front of the left eye
	positionXYZ = glm::vec3(gizmoX - 0.13f, 1.03f, gizmoZ + 0.34f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the same dark brown
	SetShaderColor(eyeDark.x, eyeDark.y, eyeDark.z, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** MUZZLE - a small tan sphere below the eyes                 ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - small and slightly flattened
	scaleXYZ = glm::vec3(0.10f, 0.075f, 0.08f);

	// set the XYZ position for the mesh - centered under the eyes,
	// standing off the face
	positionXYZ = glm::vec3(gizmoX, 0.93f, gizmoZ + 0.29f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the same tan as the ears
	SetShaderColor(skinTan.x, skinTan.y, skinTan.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** HANDS - two white spheres held out at the sides            ***/
	/*** The real figure has both paws raised, which is most of why ***/
	/*** its silhouette is not just an egg.                         ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - round puffs
	scaleXYZ = glm::vec3(0.13f, 0.13f, 0.12f);

	// set the XYZ position for the mesh - the right hand, out past
	// the side of the body and forward of it
	positionXYZ = glm::vec3(gizmoX + 0.31f, 0.62f, gizmoZ + 0.13f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// white fur
	SetShaderColor(furWhite.x, furWhite.y, furWhite.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ position for the mesh - the left hand
	positionXYZ = glm::vec3(gizmoX - 0.31f, 0.62f, gizmoZ + 0.13f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// white fur
	SetShaderColor(furWhite.x, furWhite.y, furWhite.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/
}

/***********************************************************
 *  RenderGoombaFigurine()
 *
 *  Implemented by: Matthew Randall
 *
 *  Renders the second shelf figurine, a Goomba from Mario,
 *  built from FOURTEEN transformed primitives on its display
 *  base.
 *
 *  WHAT MAKES IT READ AS A GOOMBA, working from the reference
 *  photo of the actual figure on my shelf:
 *
 *    - the HEAD SHAPE. It is not a dome. It is narrow and
 *      rounded at the crown and swells out to heavy jowls at
 *      the bottom, which is why it is built from TWO spheres
 *      of different widths stacked and overlapped rather than
 *      from one squashed ball
 *    - the BROWS, thick and angled down toward the nose. A
 *      brown head on two feet is a mushroom; the same shape
 *      with two bars tilted inward is instantly the Mario
 *      enemy. They cost two primitives and do more for the
 *      likeness than anything else here
 *    - the FANGS, two small points at the mouth line, which
 *      are the detail that stops it reading as friendly
 *
 *  The brows are rotated in OPPOSITE directions. A positive Z
 *  rotation lifts the +X end of a box, so the right brow takes
 *  a positive angle and the left a negative one, dropping both
 *  inner ends toward the center of the face.
 *
 *  The fangs use a cone turned upside down by a Z rotation of
 *  180, which leaves its point hanging below its base.
 ***********************************************************/
void SceneManager::RenderGoombaFigurine()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// where the figurine stands - mirrored across the monitor from
	// the Gizmo figurine, just right of the oval base, and short
	// enough that the camera sees it under the screen panel rather
	// than through it
	const float goombaX = 3.5f;
	const float goombaZ = -0.2f;

	// how far the eyes and brows sit either side of the center line
	// of the face, shared so the two features line up
	const float faceSpread = 0.17f;

	// the palette, named because most of these are used twice
	const glm::vec3 capBrown = glm::vec3(0.55f, 0.33f, 0.20f);
	const glm::vec3 footBrown = glm::vec3(0.40f, 0.23f, 0.13f);
	const glm::vec3 browDark = glm::vec3(0.26f, 0.15f, 0.09f);
	const glm::vec3 eyeWhite = glm::vec3(0.95f, 0.94f, 0.91f);

	/******************************************************************/
	/*** DISPLAY BASE - the disc the figure is mounted on           ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - radius 0.42, a little deeper
	// than the Gizmo base, matching the taller plinth on the real
	// figure
	scaleXYZ = glm::vec3(0.42f, 0.10f, 0.42f);

	// set the XYZ position for the mesh - resting on the desk
	positionXYZ = glm::vec3(goombaX, 0.0f, goombaZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// a mid gray for the base
	SetShaderColor(0.33f, 0.33f, 0.35f, 1.0f);

	// matte plastic: almost no specular, the way the black plastic on
	// real hardware is finished so it does not throw glare back
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** FEET - two brown spheres, stretched forward                ***/
	/*** Set wide apart and well forward, which is the stance the   ***/
	/*** real figure stands in.                                     ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - low, and longest on Z
	scaleXYZ = glm::vec3(0.19f, 0.10f, 0.26f);

	// set the XYZ position for the mesh - the right foot, standing
	// on top of the base
	positionXYZ = glm::vec3(goombaX + 0.21f, 0.16f, goombaZ + 0.04f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the darker brown of the feet
	SetShaderColor(footBrown.x, footBrown.y, footBrown.z, 1.0f);

	// painted resin: a soft sheen spread wide across the surface, the
	// way a clear coated figure carries it, so shapes this small keep
	// their curve instead of flattening out
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ position for the mesh - the left foot
	positionXYZ = glm::vec3(goombaX - 0.21f, 0.16f, goombaZ + 0.04f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the same darker brown
	SetShaderColor(footBrown.x, footBrown.y, footBrown.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** BODY - the short tan stump between the feet and the head   ***/
	/*** Deliberately small. On the real figure the head is most of ***/
	/*** the character and the body is barely visible under it.     ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - narrow and short
	scaleXYZ = glm::vec3(0.25f, 0.24f, 0.23f);

	// set the XYZ position for the mesh - the cylinder mesh has its
	// base at the origin, so this starts it just above the base disc
	positionXYZ = glm::vec3(goombaX, 0.20f, goombaZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the pale tan of the lower body
	SetShaderColor(0.90f, 0.78f, 0.62f, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** HEAD - two overlapping spheres of different widths         ***/
	/***                                                            ***/
	/*** The lower sphere is WIDE and shallow and forms the heavy   ***/
	/*** jowls; the upper one is NARROWER and taller and forms the  ***/
	/*** rounded crown. Stacking them so they overlap produces the  ***/
	/*** pear shaped head in the reference photo. A single squashed ***/
	/*** sphere gives a dome, which is a mushroom, not a Goomba.    ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - the jowls, the widest part of
	// the whole figure
	scaleXYZ = glm::vec3(0.50f, 0.30f, 0.42f);

	// set the XYZ position for the mesh - overlapping the top of the
	// tan body below it
	positionXYZ = glm::vec3(goombaX, 0.62f, goombaZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the head brown
	SetShaderColor(capBrown.x, capBrown.y, capBrown.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ scale for the mesh - the crown, narrower on X and
	// taller on Y than the jowls
	scaleXYZ = glm::vec3(0.38f, 0.36f, 0.34f);

	// set the XYZ position for the mesh - overlapping the jowls by
	// most of its height, so the two blend into one head rather
	// than reading as a snowman
	positionXYZ = glm::vec3(goombaX, 0.90f, goombaZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the same head brown
	SetShaderColor(capBrown.x, capBrown.y, capBrown.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** EYES - large pale ovals with dark pupils                   ***/
	/*** Taller than they are wide, which is what makes the stare   ***/
	/*** read as a glare rather than as surprise.                   ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - tall ovals, flattened on Z
	scaleXYZ = glm::vec3(0.14f, 0.17f, 0.07f);

	// set the XYZ position for the mesh - the right eye
	positionXYZ = glm::vec3(goombaX + faceSpread, 0.80f, goombaZ + 0.33f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// an off white, kept below 1.0 so the lighting has somewhere
	// to put a highlight
	SetShaderColor(eyeWhite.x, eyeWhite.y, eyeWhite.z, 1.0f);

	// glossy plastic: a tight highlight, which is what makes a curved
	// shape drawn in one flat color read as solid rather than as a
	// silhouette
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ position for the mesh - the left eye
	positionXYZ = glm::vec3(goombaX - faceSpread, 0.80f, goombaZ + 0.33f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the same off white
	SetShaderColor(eyeWhite.x, eyeWhite.y, eyeWhite.z, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ scale for the mesh - the pupils, small against the
	// eye so plenty of white shows around them
	scaleXYZ = glm::vec3(0.06f, 0.08f, 0.05f);

	// set the XYZ position for the mesh - the right pupil, pulled in
	// toward the center line so both eyes look inward
	positionXYZ = glm::vec3(goombaX + 0.14f, 0.79f, goombaZ + 0.38f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// near black
	SetShaderColor(0.08f, 0.07f, 0.07f, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// set the XYZ position for the mesh - the left pupil
	positionXYZ = glm::vec3(goombaX - 0.14f, 0.79f, goombaZ + 0.38f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the same near black
	SetShaderColor(0.08f, 0.07f, 0.07f, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** BROWS - two bars rotated into the scowl                    ***/
	/*** See the note at the top of this method: these two shapes   ***/
	/*** are what make the figurine a Goomba rather than a          ***/
	/*** mushroom, which is why they are worth the geometry.        ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - thick heavy bars, as wide as
	// the eyes beneath them
	scaleXYZ = glm::vec3(0.22f, 0.07f, 0.06f);

	// set the XYZ rotation for the mesh - a positive Z rotation
	// lifts the +X end, dropping the inner end of the RIGHT brow
	// toward the center of the face
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 22.0f;

	// set the XYZ position for the mesh - just above the right eye
	positionXYZ = glm::vec3(goombaX + faceSpread, 0.99f, goombaZ + 0.30f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the dark brown of the brows
	SetShaderColor(browDark.x, browDark.y, browDark.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	// set the XYZ rotation for the mesh - the mirrored angle for the
	// LEFT brow
	ZrotationDegrees = -22.0f;

	// set the XYZ position for the mesh - just above the left eye
	positionXYZ = glm::vec3(goombaX - faceSpread, 0.99f, goombaZ + 0.30f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the same dark brown
	SetShaderColor(browDark.x, browDark.y, browDark.z, 1.0f);
	SetShaderMaterial("paintedResin");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/******************************************************************/
	/*** FANGS - two small cones hanging point down                 ***/
	/*** A Z rotation of 180 turns the cone over, so its base stays ***/
	/*** at the position given and its point drops below - a tooth. ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - small and narrow
	scaleXYZ = glm::vec3(0.05f, 0.11f, 0.04f);

	// set the XYZ rotation for the mesh - turn the cone point down
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 180.0f;

	// set the XYZ position for the mesh - the right fang, started
	// inside the jowl so its wide base is hidden
	positionXYZ = glm::vec3(goombaX + 0.11f, 0.54f, goombaZ + 0.38f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the white of the teeth
	SetShaderColor(0.96f, 0.95f, 0.93f, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();

	// set the XYZ position for the mesh - the left fang
	positionXYZ = glm::vec3(goombaX - 0.11f, 0.54f, goombaZ + 0.38f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the same white
	SetShaderColor(0.96f, 0.95f, 0.93f, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();
	/****************************************************************/
}

/***********************************************************
 *  RenderDeskLamp()
 *
 *  Implemented by: Matthew Randall
 *
 *  Renders the desk lamp standing beside the keyboard, built
 *  as an articulated Pixar style lamp from EIGHT transformed
 *  primitives:
 *
 *    1. Base         - a wide flat cylinder
 *    2. Shoulder     - a sphere where the arm meets the base
 *    3. Lower arm    - a cylinder leaning out to the left
 *    4. Elbow        - a sphere at the joint
 *    5. Upper arm    - a cylinder swinging back in
 *    6. Head joint   - a sphere at the top of the arm
 *    7. Shade        - a tapered cylinder, mouth down and in,
 *                      in the same brushed steel as the arms
 *    8. Bulb         - a sphere at the mouth of the shade
 *
 *  THE ARTICULATION: every rotation in this object is around
 *  the Z axis, which swings a shape sideways within the
 *  vertical plane the lamp stands in - so the arms lean left
 *  and right, not toward or away from the camera. The lower
 *  arm leans OUT toward the desk's left edge and the upper arm
 *  swings back IN over the desk by a larger angle, which is
 *  what puts the head out above the desk rather than directly
 *  over the base - the crooked, leaning posture the Pixar lamp
 *  is known for. The three spheres at the joints are what sell
 *  it: without them the arms meet at visible hard corners, and
 *  with them the lamp reads as hinged.
 *
 *  JOINT MATH: the cylinder mesh has its BASE at the origin
 *  and its axis on +Y, and a Z rotation of angle A turns that
 *  axis into the direction (-sin A, cos A, 0). Multiplying
 *  that direction by the arm's length gives the offset from
 *  where the arm starts to where it ends, which is how each
 *  joint position below is calculated rather than guessed. The
 *  offsets are computed once as named values so that changing
 *  an arm angle moves everything above it automatically
 *  instead of breaking the chain.
 *
 *  The bulb is placed OUTSIDE the mouth of the shade rather
 *  than up inside it. A bulb fully enclosed by the cone would
 *  be invisible from every camera angle, and the reason to
 *  model one is that it gives the scene's lighting a physical
 *  source to sit a light on: light source [0] in
 *  SetupSceneLights() is positioned inside this bulb, so the
 *  warm light falling across the keyboard visibly comes FROM
 *  the lamp rather than from a point in empty air. It is the
 *  brightest and closest of the scene's four sources, which
 *  is what stands in for the spotlight the shader has no way
 *  to declare directly.
 *
 *  The bulb is also the only object in the scene surrounded by
 *  a GLOW - three additively blended shells that stack into a
 *  soft halo, so the bulb reads as switched on rather than as
 *  a pale ball. The technique, and why the brightness is
 *  carried in the color rather than the alpha, is explained at
 *  that draw call.
 ***********************************************************/
void SceneManager::RenderDeskLamp()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// where the lamp stands - forward and to the left, beside the
	// keyboard rather than back in the corner, which is where the
	// real one sits and where it can actually light the desk.
	//
	// Standing it FORWARD of the monitor's plane matters. The lamp
	// is the tallest thing on the desk after the screen, and the
	// arm reaches sideways as it rises, so from the back it would
	// disappear behind the panel. Out here it is seen against the
	// desk instead - and X is set so that the shade still falls
	// left of the panel's edge from the default camera, leaving the
	// screen unobstructed
	const float lampX = -6.3f;
	const float lampZ = 1.2f;

	// the two arm angles and lengths. The lower arm leans out and
	// the upper arm swings back in by more, which walks the head out
	// over the desk (see THE ARTICULATION above)
	const float lowerArmAngle = 20.0f;
	const float lowerArmLength = 2.70f;
	const float upperArmAngle = -45.0f;
	const float upperArmLength = 2.40f;

	// the angle the shade hangs at. This tips its narrow top away
	// over the arm and swings its wide open mouth down and in
	// toward the rest of the desk, so the lamp aims at the scene
	// rather than straight down at its own base
	const float shadeAngle = 30.0f;

	// height of the base disc, reused to seat the arm on top of it
	const float baseHeight = 0.16f;

	// the thickness of both arms, and the radius of the joints that
	// hinge them. The joints are set wider than the arms so the arms
	// appear to enter them rather than to butt against them
	const float armRadius = 0.12f;
	const float jointRadius = 0.22f;

	// turn each arm's angle into the direction its axis points, so
	// the joint positions below can be calculated instead of
	// guessed (see JOINT MATH above)
	const float lowerRadians = glm::radians(lowerArmAngle);
	const glm::vec3 lowerDirection = glm::vec3(
		-std::sin(lowerRadians), std::cos(lowerRadians), 0.0f);

	const float upperRadians = glm::radians(upperArmAngle);
	const glm::vec3 upperDirection = glm::vec3(
		-std::sin(upperRadians), std::cos(upperRadians), 0.0f);

	// the three joint positions, each one built from the joint
	// below it plus the arm that connects them
	const glm::vec3 shoulder = glm::vec3(lampX, baseHeight, lampZ);
	const glm::vec3 elbow = shoulder + (lowerDirection * lowerArmLength);
	const glm::vec3 headJoint = elbow + (upperDirection * upperArmLength);

	/******************************************************************/
	/*** BASE - wide flat cylinder                                  ***/
	/*** Wide and heavy looking, because the lamp above it leans    ***/
	/*** well off center and a narrow base would look like it       ***/
	/*** should tip over.                                           ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - radius 1.15
	scaleXYZ = glm::vec3(1.15f, baseHeight, 1.15f);

	// set the XYZ position for the mesh - the cylinder mesh has its
	// base at the origin, so Y = 0 rests it on the desk surface
	positionXYZ = glm::vec3(lampX, 0.0f, lampZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the circular brushed stainless image is left untiled so its
	// radial pattern wraps the disc exactly once, the same reason
	// it is untiled on the monitor base
	SetTextureUVScale(1.0f, 1.0f);

	// apply the brushed stainless texture
	SetShaderTexture("baseMetal");

	// brushed metal: the strongest specular in the scene, which pulls
	// a bright rim around the curve and reads as steel rather than as
	// gray paint
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** SHOULDER JOINT - sphere at the foot of the lower arm       ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - see jointRadius above
	scaleXYZ = glm::vec3(jointRadius, jointRadius, jointRadius);

	// set the XYZ position for the mesh
	positionXYZ = shoulder;

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// a mid gray for all three joints, darker than the arms so the
	// hinges stand out against them
	SetShaderColor(0.34f, 0.35f, 0.38f, 1.0f);
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** LOWER ARM - cylinder leaning out toward the desk edge      ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - a slim rod
	scaleXYZ = glm::vec3(armRadius, lowerArmLength, armRadius);

	// set the XYZ rotation for the mesh - a positive Z rotation
	// leans the arm out to the left, away from the rest of the desk
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = lowerArmAngle;

	// set the XYZ position for the mesh - the rotation pivots around
	// the mesh's base, so the arm hinges cleanly at the shoulder
	positionXYZ = shoulder;

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the arm repeats the brushed steel three times up its length,
	// which keeps the brushing from being stretched into long
	// smeared streaks over a shape this thin and tall
	SetTextureUVScale(1.0f, 3.0f);

	// apply the brushed stainless texture
	SetShaderTexture("baseMetal");
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** ELBOW JOINT - sphere where the two arms meet               ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - the same size as the shoulder
	scaleXYZ = glm::vec3(jointRadius, jointRadius, jointRadius);

	// set the XYZ position for the mesh - the calculated end of the
	// lower arm, so the joint follows if the arm angle is retuned
	positionXYZ = elbow;

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the same joint gray
	SetShaderColor(0.34f, 0.35f, 0.38f, 1.0f);
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** UPPER ARM - cylinder swinging back in over the desk        ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - the same thickness as the
	// lower arm, slightly shorter
	scaleXYZ = glm::vec3(armRadius, upperArmLength, armRadius);

	// set the XYZ rotation for the mesh - a NEGATIVE Z rotation
	// swings this arm the opposite way from the lower one, throwing
	// the head out over the desk
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = upperArmAngle;

	// set the XYZ position for the mesh - hinged at the elbow
	positionXYZ = elbow;

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the same tiling as the lower arm
	SetTextureUVScale(1.0f, 3.0f);

	// apply the brushed stainless texture
	SetShaderTexture("baseMetal");
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** HEAD JOINT - sphere at the top of the arm                  ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - the largest of the three
	// joints, since it carries the shade
	scaleXYZ = glm::vec3(
		jointRadius + 0.03f, jointRadius + 0.03f, jointRadius + 0.03f);

	// set the XYZ position for the mesh - the calculated end of the
	// upper arm
	positionXYZ = headJoint;

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the same joint gray
	SetShaderColor(0.34f, 0.35f, 0.38f, 1.0f);
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** SHADE - tapered cylinder hung from the head joint          ***/
	/***                                                            ***/
	/*** A lamp shade is a TRUNCATED cone - a wide open mouth at    ***/
	/*** the bottom and a small flat opening at the top where the   ***/
	/*** fitting passes through. The tapered cylinder mesh is that  ***/
	/*** shape already: it stands with its wide end at the origin   ***/
	/*** and narrows as it rises, so no rotation is needed to get   ***/
	/*** the profile, only the tilt that aims it.                   ***/
	/***                                                            ***/
	/*** This replaced a plain cone. A cone runs all the way to a   ***/
	/*** POINT, and once tilted it read as a pennant on a pole      ***/
	/*** rather than as a shade - the flat top is most of what      ***/
	/*** makes the silhouette recognizable as a lamp.               ***/
	/***                                                            ***/
	/*** The mesh grows UP from where it is positioned, so the      ***/
	/*** shade is placed by working BACK from the head joint:       ***/
	/*** stepping one shade height down the tilted axis puts the    ***/
	/*** mouth where it belongs and leaves the narrow top meeting   ***/
	/*** the joint, with the arm entering the shade where a real    ***/
	/*** fitting would.                                             ***/
	/******************************************************************/
	// the direction the shade's axis points, from its mouth up to
	// its narrow top. Both the shade and the bulb are placed along
	// this vector, so retuning shadeAngle swings the two together
	// instead of pulling them apart
	const float shadeRadians = glm::radians(shadeAngle);
	const glm::vec3 shadeAxis = glm::vec3(
		-std::sin(shadeRadians), std::cos(shadeRadians), 0.0f);

	// how deep the shade is from its mouth to its top
	const float shadeHeight = 1.15f;

	// where the mouth of the shade sits - one shade height back down
	// the axis from the joint it hangs off
	const glm::vec3 shadeMouth = headJoint - (shadeAxis * shadeHeight);

	// set the XYZ scale for the mesh - mouth radius 0.85
	scaleXYZ = glm::vec3(0.85f, shadeHeight, 0.85f);

	// set the XYZ rotation for the mesh - tilt the shade so it aims
	// in toward the rest of the desk
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = shadeAngle;

	// set the XYZ position for the mesh - the mesh's wide end is at
	// its origin, so this places the mouth and lets the shade rise
	// from there up to the joint
	positionXYZ = shadeMouth;

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the shade takes the same brushed stainless as the base and the
	// arms, so the whole lamp reads as one piece of hardware. A
	// painted shade made the head look bolted on from a different
	// object. Left untiled: one wrap of the brushing suits a shape
	// this size, where repeating it would band the surface
	SetTextureUVScale(1.0f, 1.0f);

	// apply the brushed stainless texture
	SetShaderTexture("baseMetal");
	SetShaderMaterial("brushedMetal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** BULB - sphere at the mouth of the shade                    ***/
	/*** Set just below the mouth rather than up inside the shade.  ***/
	/*** The wide end of the mesh is capped, so a bulb tucked in    ***/
	/*** behind it would be sealed out of sight from every angle.   ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - slightly taller than wide,
	// which is closer to a bulb than a perfect ball
	scaleXYZ = glm::vec3(0.28f, 0.34f, 0.28f);

	// where the bulb sits - stepped a little further down the same
	// axis, so it hangs clear of the mouth. Named rather than
	// assigned straight into positionXYZ, because the glow shells
	// below have to be centered on the same point
	const glm::vec3 bulbCenter = shadeMouth - (shadeAxis * 0.17f);

	// set the XYZ position for the mesh
	positionXYZ = bulbCenter;

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// very nearly white, with just enough warmth left in the blue
	// channel to keep it from looking clinical. This is the hottest
	// color in the scene and the only one the lighting does not
	// multiply down, so the bulb reads as the burning center that
	// the glow below falls away from
	SetShaderColor(1.00f, 0.97f, 0.88f, 1.0f);

	// LIGHTING IS SWITCHED OFF FOR THE BULB, the same treatment the
	// monitor's display face gets in RenderMonitor() and for the
	// same reason: this object emits light rather than reflecting
	// it, and no material can describe a surface that produces its
	// own brightness.
	//
	// The problem is sharper here than it is on the screen. Light
	// source [0] sits INSIDE this sphere, which means it cannot
	// light it - the direction from any point on the bulb's surface
	// back to the light points INWARD, opposite the surface normal,
	// so the diffuse term is zero everywhere on it. Lit normally,
	// the one object in the scene that is the source of the warm
	// light falling across the desk would be shaded only by the two
	// dim fill lights across the room, and would come out DARKER
	// than the desk it is lighting. Drawn unlit it renders at its
	// full pale warm white, which is what a bulb that is switched
	// on looks like, and it gives the eye something to trace the
	// warm light on the keyboard back to
	m_pShaderManager->setBoolValue(g_UseLightingName, false);

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/******************************************************************/
	/*** GLOW - three transparent shells around the bulb            ***/
	/***                                                            ***/
	/*** A bulb drawn as a solid pale sphere looks like a pale      ***/
	/*** sphere. What makes a real bulb read as ON is not the bulb  ***/
	/*** itself but the halo around it - light scattering in the    ***/
	/*** air and in the camera, which has no hard edge and fades    ***/
	/*** outward. Geometry alone cannot produce that, because every ***/
	/*** mesh here has a hard edge by definition.                   ***/
	/***                                                            ***/
	/*** ADDITIVE BLENDING can. With glBlendFunc(GL_ONE, GL_ONE)    ***/
	/*** the color being drawn is ADDED to what is already in the   ***/
	/*** frame rather than replacing it, which is what light itself ***/
	/*** does - light falling on a surface makes it brighter, never ***/
	/*** darker. So three plain spheres of increasing size, each    ***/
	/*** drawn in a dim fraction of the glow color, stack into a    ***/
	/*** halo that is brightest at the center where all three       ***/
	/*** overlap and fades to nothing at the outer edge where only  ***/
	/*** the faintest one reaches.                                  ***/
	/***                                                            ***/
	/*** The BRIGHTNESS IS CARRIED IN THE COLOR VALUES rather than  ***/
	/*** in the alpha channel. Scaling the color down and blending  ***/
	/*** with GL_ONE gives the same result as a full strength color ***/
	/*** blended by its alpha, without depending on the fragment    ***/
	/*** shader to carry alpha through to its output.               ***/
	/******************************************************************/
	// the shells, from the tightest and brightest outward. Each is a
	// radius paired with the fraction of the glow color it
	// contributes - roughly halving at each step out, which gives
	// the halo a steep falloff close to the bulb and a long faint
	// tail beyond it
	const int glowShellCount = 3;
	const float glowShellRadius[glowShellCount] = { 0.46f, 0.72f, 1.10f };
	const float glowShellStrength[glowShellCount] = { 0.22f, 0.11f, 0.05f };

	// warmer than the bulb's near white core, because the light an
	// incandescent bulb throws is warmer than the filament at its
	// center looks
	const glm::vec3 glowColor = glm::vec3(1.00f, 0.86f, 0.58f);

	// switch on additive blending, for these three shells only
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE, GL_ONE);

	// stop the shells writing to the DEPTH buffer, while leaving the
	// depth TEST on. Without this the outermost shell would write
	// its depth first and then hide the brighter shells inside it,
	// collapsing the halo into one flat disc. With depth writing off
	// all three reach the frame and add together, while the depth
	// test still lets solid geometry in front of the bulb - the
	// shade, at most camera angles - correctly cover it
	glDepthMask(GL_FALSE);

	for (int shell = 0; shell < glowShellCount; shell++)
	{
		// set the XYZ scale for the mesh - a sphere, so the same
		// radius on all three axes
		scaleXYZ = glm::vec3(
			glowShellRadius[shell],
			glowShellRadius[shell],
			glowShellRadius[shell]);

		// set the XYZ position for the mesh - every shell is
		// centered on the bulb it surrounds
		positionXYZ = bulbCenter;

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

		// the glow color scaled down to this shell's contribution
		SetShaderColor(
			glowColor.x * glowShellStrength[shell],
			glowColor.y * glowShellStrength[shell],
			glowColor.z * glowShellStrength[shell],
			1.0f);

		// draw the mesh with transformation values
		m_basicMeshes->DrawSphereMesh();
	}

	// put every piece of state back as it was found. Blending, depth
	// writing and lighting are all GLOBAL settings rather than per
	// object ones, so leaving any of the three switched would
	// silently change how every object drawn after the lamp renders
	glDepthMask(GL_TRUE);
	glDisable(GL_BLEND);
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
	/****************************************************************/
}

/***********************************************************
 *  RenderTumbler()
 *
 *  Implemented by: Matthew Randall
 *
 *  Renders the Pokeball tumbler standing to the right of the
 *  monitor, built from TWENTY TWO transformed primitives.
 *
 *  THE BODY is a plain white insulated tumbler, not a
 *  Pokeball. The reference photo shows a white cup that
 *  narrows to a foot small enough for a cup holder, under a
 *  smoked lid with a red straw and a black side handle - the
 *  Pokeball is PRINTED on the front, not built into the shape
 *  of the cup:
 *
 *    1. Foot        - a narrow cylinder
 *    2. Taper       - an upside down cone sweeping the body
 *                     width down to the foot
 *    3. Body        - the main white cylinder
 *    4. Lid         - a smoked cylinder on top
 *    5. Lid rim     - a thin dark band around the lid
 *    6. Straw       - a thin red cylinder rising from the lid
 *    7, 8, 9. Handle - two arms and a post forming a squared C
 *
 *  THE EMBLEM is the printed Pokeball, built as a shallow
 *  medallion stacked on the front of the body. There is no
 *  way to draw a flat printed graphic with these meshes, so
 *  it is modeled as raised geometry instead:
 *
 *    10. Outline     - a dark disc a little wider than the
 *                      ball, showing as a ring around it
 *    11. White half  - a pale disc covering all but that ring
 *    12-19. Red half - eight boxes stacked into a semicircle
 *    20. Band        - a thin box across the middle
 *    21. Button ring - a dark disc behind the button
 *    22. Button      - a smaller pale disc at the center
 *
 *  WHY THE RED HALF IS A STACK OF BOXES: none of the meshes
 *  in ShapeMeshes produces a half circle. The cylinder and
 *  the sphere both give a FULL circle seen face on, and
 *  masking the unwanted half with another shape does not work
 *  either - any mask wide enough to cover the widest part of
 *  the circle overhangs it everywhere else, and the cup it
 *  would overhang onto is curved, so the mask would stand off
 *  the surface at its edges. Stacking boxes whose widths are
 *  computed from the circle equation fits the arc directly
 *  and needs no mask at all.
 *
 *  THE OUTLINE RING is why the white lower half gets a disc of
 *  its own instead of just letting the white cup show through.
 *  A ring needs something drawn BEHIND the ball to show around
 *  its edge, and once a dark disc is back there, the lower half
 *  has to be covered or it reads as black rather than white.
 *  The two discs together give an outline that runs the whole
 *  way around, which is what makes the emblem hold its shape
 *  against a white cup.
 *
 *  The emblem parts are stacked in increasing Z so each sits
 *  in front of the one behind it. That ordering is what keeps
 *  the band from being buried in the red bars and the button
 *  from sinking into the band - the depth buffer resolves
 *  them correctly, but only because they never share a depth.
 ***********************************************************/
void SceneManager::RenderTumbler()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// where the tumbler stands, to the right of the monitor and
	// behind the mouse
	const float tumblerX = 7.0f;
	const float tumblerZ = 0.2f;

	// the radius of the main body, reused to place the handle and
	// the emblem against its surface
	const float bodyRadius = 0.78f;

	// the radius of the narrow foot the cup steps down to
	const float footRadius = 0.52f;

	// the running heights of the stack, named so each section stays
	// seated on the one below if any is retuned
	const float footTop = 0.60f;
	const float taperTop = 0.95f;
	const float bodyTop = 2.45f;

	// the taper cone is drawn a hair wider than the body it meets,
	// so the two overlap instead of presenting two surfaces at the
	// same radius - identical radii would leave the walls fighting
	// for the same depth along the join
	const float taperRadius = bodyRadius + 0.01f;

	// the taper starts slightly INSIDE the foot rather than exactly
	// at its top edge, so the cone is already wider than the foot
	// where the two meet and no seam can open between them
	const float taperBottom = footTop - 0.03f;

	// how tall the whole cone has to be. A cone narrows all the way
	// to a point, so only its upper portion is the frustum this
	// needs - the rest continues down inside the foot, hidden. The
	// height that leaves the cone measuring exactly footRadius
	// across at taperBottom comes straight from similar triangles:
	// the radius falls off linearly, so the fraction of the height
	// spanned equals the fraction of the radius lost
	const float taperHeight =
		(taperTop - taperBottom) / (1.0f - (footRadius / taperRadius));

	// the white of the cup. Deliberately not pure white - a surface
	// already at 1.0 has nowhere left to go when the lighting adds
	// a specular highlight on top of it
	const float shellR = 0.93f;
	const float shellG = 0.93f;
	const float shellB = 0.94f;

	/******************************************************************/
	/*** FOOT - the narrow base of the cup                          ***/
	/*** The reference tumbler steps IN at the bottom so it fits a  ***/
	/*** cup holder, which is the detail that separates it from a   ***/
	/*** plain straight sided cup.                                  ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - noticeably narrower than the
	// body above it
	scaleXYZ = glm::vec3(footRadius, footTop, footRadius);

	// set the XYZ position for the mesh - the cylinder mesh has its
	// base at the origin, so Y = 0 rests it on the desk surface
	positionXYZ = glm::vec3(tumblerX, 0.0f, tumblerZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the white shell
	SetShaderColor(shellR, shellG, shellB, 1.0f);

	// glossy plastic: a tight highlight, which is what makes a curved
	// shape drawn in one flat color read as solid rather than as a
	// silhouette
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** TAPER - the shoulder sweeping the body down to the foot    ***/
	/***                                                            ***/
	/*** An UPSIDE DOWN CONE. The cone mesh stands with its wide    ***/
	/*** base at the origin and its point above; a Z rotation of    ***/
	/*** 180 turns it over, leaving the wide end at the position    ***/
	/*** given and the point hanging below it. That is exactly a    ***/
	/*** shoulder - full body width at the top, narrowing smoothly  ***/
	/*** as it drops.                                               ***/
	/***                                                            ***/
	/*** This replaced a short wide cylinder used as a step ring.   ***/
	/*** A cylinder can only ever change radius in one abrupt jump, ***/
	/*** which read as a collar bolted onto the cup rather than as  ***/
	/*** the cup narrowing. A cone changes radius continuously, so  ***/
	/*** the wall actually sweeps in.                               ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - full body width across, and
	// tall enough that the visible upper section spans the shoulder
	// (see the taperHeight note above)
	scaleXYZ = glm::vec3(taperRadius, taperHeight, taperRadius);

	// set the XYZ rotation for the mesh - turn the cone over so its
	// wide end is uppermost
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 180.0f;

	// set the XYZ position for the mesh - the rotation pivots around
	// the cone's base, so positioning it at the top of the shoulder
	// grows the cone downward from there
	positionXYZ = glm::vec3(tumblerX, taperTop, tumblerZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the same white as the rest of the shell, so the taper reads as
	// the cup narrowing rather than as a separate fitting
	SetShaderColor(shellR, shellG, shellB, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();

	// clear the rotation so it does not carry into the sections below
	ZrotationDegrees = 0.0f;
	/****************************************************************/

	/******************************************************************/
	/*** BODY - the main white wall of the cup                      ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - rising from the taper to the
	// lid
	scaleXYZ = glm::vec3(bodyRadius, bodyTop - (taperTop - 0.02f), bodyRadius);

	// set the XYZ position for the mesh - starting just below the
	// top of the taper, so the two overlap
	positionXYZ = glm::vec3(tumblerX, taperTop - 0.02f, tumblerZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the white shell
	SetShaderColor(shellR, shellG, shellB, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** LID - smoked plastic cap                                   ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - slightly wider than the body,
	// so it overhangs the rim the way a snap on lid does
	scaleXYZ = glm::vec3(0.81f, 0.25f, 0.81f);

	// set the XYZ position for the mesh - seated on the body
	positionXYZ = glm::vec3(tumblerX, bodyTop - 0.03f, tumblerZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the smoked gray of the lid
	SetShaderColor(0.48f, 0.49f, 0.52f, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** LID RIM - the dark band around the top edge                ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - a thin collar, wider again
	// than the lid
	scaleXYZ = glm::vec3(0.84f, 0.07f, 0.84f);

	// set the XYZ position for the mesh - at the top of the lid
	positionXYZ = glm::vec3(tumblerX, bodyTop + 0.16f, tumblerZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// near black for the rim
	SetShaderColor(0.16f, 0.16f, 0.18f, 1.0f);

	// matte plastic: almost no specular, the way the black plastic on
	// real hardware is finished so it does not throw glare back
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** STRAW - thin red cylinder through the lid                  ***/
	/******************************************************************/
	// set the XYZ scale for the mesh - very thin and tall
	scaleXYZ = glm::vec3(0.055f, 1.55f, 0.055f);

	// set the XYZ position for the mesh - started inside the lid so
	// its bottom end is hidden rather than floating above the hole
	positionXYZ = glm::vec3(tumblerX - 0.10f, bodyTop + 0.05f, tumblerZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// the red straw
	SetShaderColor(0.82f, 0.15f, 0.14f, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** HANDLE - two arms and a post forming a squared C           ***/
	/***                                                            ***/
	/*** A rounded handle would want a half torus; this builds the  ***/
	/*** same silhouette from the cylinder mesh already loaded, by  ***/
	/*** laying two of them on their sides as the arms and standing ***/
	/*** a third between their outer ends. As with the mouse wheel, ***/
	/*** a Z rotation of -90 swings a cylinder's axis onto +X, and  ***/
	/*** the shape then grows out from the point it is positioned   ***/
	/*** at - so both arms start inside the wall of the cup and     ***/
	/*** emerge from it with no visible join.                       ***/
	/******************************************************************/
	// where the two arms sit on the cup, and how far they reach out
	const float handleLower = 1.25f;
	const float handleUpper = 2.18f;
	const float handleReach = 0.62f;

	// set the XYZ scale for the mesh - a thin rod reaching out from
	// just inside the wall of the cup
	scaleXYZ = glm::vec3(0.085f, handleReach, 0.085f);

	// set the XYZ rotation for the mesh - lay the arm over so it
	// runs out to the right
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -90.0f;

	// set the XYZ position for the mesh - the LOWER arm, started
	// 0.10 inside the wall
	positionXYZ = glm::vec3(
		tumblerX + bodyRadius - 0.10f, handleLower, tumblerZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the black handle
	SetShaderColor(0.13f, 0.13f, 0.14f, 1.0f);
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	// set the XYZ position for the mesh - the UPPER arm
	positionXYZ = glm::vec3(
		tumblerX + bodyRadius - 0.10f, handleUpper, tumblerZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the same black
	SetShaderColor(0.13f, 0.13f, 0.14f, 1.0f);
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	// set the XYZ scale for the mesh - the upright post, long enough
	// to overlap both arms at its ends
	scaleXYZ = glm::vec3(0.085f, (handleUpper - handleLower) + 0.10f, 0.085f);

	// set the XYZ rotation for the mesh - the post stands straight,
	// so the rotation used by the arms is cleared
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh - at the outer end of both
	// arms, started slightly below the lower one so the corner is
	// filled in
	positionXYZ = glm::vec3(
		tumblerX + bodyRadius - 0.10f + handleReach,
		handleLower - 0.05f,
		tumblerZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the same black
	SetShaderColor(0.13f, 0.13f, 0.14f, 1.0f);
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/******************************************************************/
	/*** EMBLEM - the printed Pokeball on the front of the cup      ***/
	/*** See the notes at the top of this method for why this is    ***/
	/*** raised geometry, why the red half is a stack of boxes, and ***/
	/*** why the white lower half needs a disc of its own.          ***/
	/******************************************************************/
	// the center of the emblem, and the radius of the ball. The Z
	// value is the front surface of the body, so the parts below
	// stack outward from the wall of the cup
	const float emblemY = 1.70f;
	const float emblemZ = tumblerZ + bodyRadius;
	const float emblemRadius = 0.46f;

	/*** OUTLINE - a dark disc behind the whole ball ***/
	// set the XYZ scale for the mesh - a touch wider than the ball
	// itself, so what shows around the edge is a thin ring
	scaleXYZ = glm::vec3(emblemRadius + 0.045f, 0.02f, emblemRadius + 0.045f);

	// set the XYZ rotation for the mesh - an X rotation of 90 swings
	// the cylinder's axis from +Y onto +Z, turning it into a disc
	// that faces the camera
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh - the rotation pivots around
	// the mesh's base, so the disc grows forward from the wall
	positionXYZ = glm::vec3(tumblerX, emblemY, emblemZ - 0.015f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// near black for the outline
	SetShaderColor(0.10f, 0.10f, 0.11f, 1.0f);
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/*** WHITE LOWER HALF - a disc covering all but the rim ***/
	// set the XYZ scale for the mesh - the ball's own radius, which
	// leaves the outline disc behind it showing as a ring
	scaleXYZ = glm::vec3(emblemRadius, 0.02f, emblemRadius);

	// set the XYZ position for the mesh - just in front of the
	// outline
	positionXYZ = glm::vec3(tumblerX, emblemY, emblemZ + 0.008f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the same white as the cup. This disc is what the red bars sit
	// on: its lower half stays visible as the white bottom of the
	// ball, and drawing it rather than letting the cup show through
	// is what allows the outline ring to run all the way around
	SetShaderColor(shellR, shellG, shellB, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	// clear the rotation so it does not carry into the bars below
	XrotationDegrees = 0.0f;

	/*** RED UPPER HALF - a stack of boxes fitted to the arc ***/
	// how many bars the half circle is cut into, and how tall each
	// one is. Eight is enough that the stepping is not obvious at
	// the size the emblem occupies on screen, and raising it costs
	// nothing but draw calls if it ever needs to be smoother
	const int emblemBars = 8;
	const float barHeight = emblemRadius / emblemBars;

	for (int bar = 0; bar < emblemBars; bar++)
	{
		// the height of the MIDDLE of this bar above the center line
		// of the ball. Measuring from the middle rather than from an
		// edge splits the error - the bar runs a little wide at its
		// top and a little narrow at its bottom instead of missing
		// the arc on one side by the full amount
		const float barMiddle = (bar + 0.5f) * barHeight;

		// the circle equation, solved for width at that height:
		// x = sqrt(r^2 - y^2). This is what fits the stack to the
		// arc instead of to a guess
		const float barHalfWidth = std::sqrt(
			(emblemRadius * emblemRadius) - (barMiddle * barMiddle));

		// set the XYZ scale for the mesh - the fitted width, one
		// bar's height plus a hair of overlap so no hairline gap
		// opens between neighboring bars, and almost flat on Z so
		// the emblem sits on the cup like print rather than bulging
		// off it
		scaleXYZ = glm::vec3(
			barHalfWidth * 2.0f, barHeight + 0.004f, 0.022f);

		// set the XYZ position for the mesh - stacked upward from
		// the center line of the ball
		positionXYZ = glm::vec3(
			tumblerX, emblemY + barMiddle, emblemZ + 0.040f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

		// the Pokeball red
		SetShaderColor(0.85f, 0.17f, 0.15f, 1.0f);
		SetShaderMaterial("glossyPlastic");

		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();
	}

	/*** BAND - thin box across the middle of the ball ***/
	// set the XYZ scale for the mesh - as wide as the ball, and thin
	// enough on Y to read as a stripe
	scaleXYZ = glm::vec3(emblemRadius * 2.0f, 0.075f, 0.022f);

	// set the XYZ position for the mesh - on the center line, and
	// forward of the red half so it is not buried by it
	positionXYZ = glm::vec3(tumblerX, emblemY, emblemZ + 0.063f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// near black for the band
	SetShaderColor(0.10f, 0.10f, 0.11f, 1.0f);
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/*** BUTTON RING - dark disc behind the button ***/
	// set the XYZ scale for the mesh - radius 0.17, very thin
	scaleXYZ = glm::vec3(0.17f, 0.02f, 0.17f);

	// set the XYZ rotation for the mesh - an X rotation of 90 swings
	// the cylinder's axis from +Y onto +Z, turning it into a disc
	// that faces the camera
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh - the rotation pivots around
	// the mesh's base, so the disc grows forward from here
	positionXYZ = glm::vec3(tumblerX, emblemY, emblemZ + 0.066f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the same near black as the band
	SetShaderColor(0.10f, 0.10f, 0.11f, 1.0f);
	SetShaderMaterial("mattePlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/*** BUTTON - the white center ***/
	// set the XYZ scale for the mesh - smaller than the ring, which
	// leaves a dark outline showing around it
	scaleXYZ = glm::vec3(0.12f, 0.02f, 0.12f);

	// set the XYZ position for the mesh - in front of the ring
	positionXYZ = glm::vec3(tumblerX, emblemY, emblemZ + 0.078f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// the same white as the cup
	SetShaderColor(shellR, shellG, shellB, 1.0f);
	SetShaderMaterial("glossyPlastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/
}
